goog.provide('treetrunkgenerator');
/**
 * This function is able to give a unique id for tree trunk and register the global start time of this tree trunk.
 */
treetrunkgenerator.create_tree_trunk = (function treetrunkgenerator$create_tree_trunk(sim_time){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),cljs.core.random_uuid(),new cljs.core.Keyword(null,"global-start-time","global-start-time",688057299),sim_time], null);
});
/**
 * The function is able to register a start time to a tree trunk with given work station id.
 */
treetrunkgenerator.stample_start_time = (function treetrunkgenerator$stample_start_time(treetrunk,ws_id,sim_time){
return cljs.core.assoc_in(treetrunk,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [ws_id,new cljs.core.Keyword(null,"start-time","start-time",814801386)], null),sim_time);
});
/**
 * The function is able to register a end time to a tree trunk with given work station id.
 */
treetrunkgenerator.stample_end_time = (function treetrunkgenerator$stample_end_time(treetrunk,ws_id,sim_time){
return cljs.core.assoc_in(treetrunk,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [ws_id,new cljs.core.Keyword(null,"end-time","end-time",-1849817460)], null),sim_time);
});
/**
 * The function is able to register a global end time to a tree trunk.
 */
treetrunkgenerator.stample_global_end_time = (function treetrunkgenerator$stample_global_end_time(treetrunk,sim_time){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(treetrunk,new cljs.core.Keyword(null,"global-end-time","global-end-time",-364303774),sim_time);
});

//# sourceMappingURL=treetrunkgenerator.js.map
