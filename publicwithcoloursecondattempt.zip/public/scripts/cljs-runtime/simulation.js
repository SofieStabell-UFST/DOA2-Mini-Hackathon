goog.provide('simulation');
if((typeof simulation !== 'undefined') && (typeof simulation.paused_QMARK_ !== 'undefined')){
} else {
simulation.paused_QMARK_ = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(true);
}
if((typeof simulation !== 'undefined') && (typeof simulation.sim_time !== 'undefined')){
} else {
simulation.sim_time = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.interval !== 'undefined')){
} else {
simulation.interval = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null);
}
if((typeof simulation !== 'undefined') && (typeof simulation.queues !== 'undefined')){
} else {
simulation.queues = cljs.core.vec((function (){var iter__4611__auto__ = (function simulation$iter__26941(s__26942){
return (new cljs.core.LazySeq(null,(function (){
var s__26942__$1 = s__26942;
while(true){
var temp__5753__auto__ = cljs.core.seq(s__26942__$1);
if(temp__5753__auto__){
var s__26942__$2 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(s__26942__$2)){
var c__4609__auto__ = cljs.core.chunk_first(s__26942__$2);
var size__4610__auto__ = cljs.core.count(c__4609__auto__);
var b__26944 = cljs.core.chunk_buffer(size__4610__auto__);
if((function (){var i__26943 = (0);
while(true){
if((i__26943 < size__4610__auto__)){
var _ = cljs.core._nth(c__4609__auto__,i__26943);
cljs.core.chunk_append(b__26944,reagent.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY));

var G__26973 = (i__26943 + (1));
i__26943 = G__26973;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__26944),simulation$iter__26941(cljs.core.chunk_rest(s__26942__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__26944),null);
}
} else {
var _ = cljs.core.first(s__26942__$2);
return cljs.core.cons(reagent.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentVector.EMPTY),simulation$iter__26941(cljs.core.rest(s__26942__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4611__auto__(cljs.core.range.cljs$core$IFn$_invoke$arity$1((5)));
})());
}
if((typeof simulation !== 'undefined') && (typeof simulation.current_times !== 'undefined')){
} else {
simulation.current_times = cljs.core.vec((function (){var iter__4611__auto__ = (function simulation$iter__26945(s__26946){
return (new cljs.core.LazySeq(null,(function (){
var s__26946__$1 = s__26946;
while(true){
var temp__5753__auto__ = cljs.core.seq(s__26946__$1);
if(temp__5753__auto__){
var s__26946__$2 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(s__26946__$2)){
var c__4609__auto__ = cljs.core.chunk_first(s__26946__$2);
var size__4610__auto__ = cljs.core.count(c__4609__auto__);
var b__26948 = cljs.core.chunk_buffer(size__4610__auto__);
if((function (){var i__26947 = (0);
while(true){
if((i__26947 < size__4610__auto__)){
var _ = cljs.core._nth(c__4609__auto__,i__26947);
cljs.core.chunk_append(b__26948,reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0)));

var G__26974 = (i__26947 + (1));
i__26947 = G__26974;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__26948),simulation$iter__26945(cljs.core.chunk_rest(s__26946__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__26948),null);
}
} else {
var _ = cljs.core.first(s__26946__$2);
return cljs.core.cons(reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0)),simulation$iter__26945(cljs.core.rest(s__26946__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4611__auto__(cljs.core.range.cljs$core$IFn$_invoke$arity$1((4)));
})());
}
if((typeof simulation !== 'undefined') && (typeof simulation.current_logs !== 'undefined')){
} else {
simulation.current_logs = cljs.core.vec((function (){var iter__4611__auto__ = (function simulation$iter__26949(s__26950){
return (new cljs.core.LazySeq(null,(function (){
var s__26950__$1 = s__26950;
while(true){
var temp__5753__auto__ = cljs.core.seq(s__26950__$1);
if(temp__5753__auto__){
var s__26950__$2 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(s__26950__$2)){
var c__4609__auto__ = cljs.core.chunk_first(s__26950__$2);
var size__4610__auto__ = cljs.core.count(c__4609__auto__);
var b__26952 = cljs.core.chunk_buffer(size__4610__auto__);
if((function (){var i__26951 = (0);
while(true){
if((i__26951 < size__4610__auto__)){
var _ = cljs.core._nth(c__4609__auto__,i__26951);
cljs.core.chunk_append(b__26952,reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null));

var G__26975 = (i__26951 + (1));
i__26951 = G__26975;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__26952),simulation$iter__26949(cljs.core.chunk_rest(s__26950__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__26952),null);
}
} else {
var _ = cljs.core.first(s__26950__$2);
return cljs.core.cons(reagent.core.atom.cljs$core$IFn$_invoke$arity$1(null),simulation$iter__26949(cljs.core.rest(s__26950__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4611__auto__(cljs.core.range.cljs$core$IFn$_invoke$arity$1((4)));
})());
}
if((typeof simulation !== 'undefined') && (typeof simulation.process_times !== 'undefined')){
} else {
simulation.process_times = cljs.core.vec((function (){var iter__4611__auto__ = (function simulation$iter__26953(s__26954){
return (new cljs.core.LazySeq(null,(function (){
var s__26954__$1 = s__26954;
while(true){
var temp__5753__auto__ = cljs.core.seq(s__26954__$1);
if(temp__5753__auto__){
var s__26954__$2 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(s__26954__$2)){
var c__4609__auto__ = cljs.core.chunk_first(s__26954__$2);
var size__4610__auto__ = cljs.core.count(c__4609__auto__);
var b__26956 = cljs.core.chunk_buffer(size__4610__auto__);
if((function (){var i__26955 = (0);
while(true){
if((i__26955 < size__4610__auto__)){
var _ = cljs.core._nth(c__4609__auto__,i__26955);
cljs.core.chunk_append(b__26956,reagent.core.atom.cljs$core$IFn$_invoke$arity$1((2)));

var G__26976 = (i__26955 + (1));
i__26955 = G__26976;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__26956),simulation$iter__26953(cljs.core.chunk_rest(s__26954__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__26956),null);
}
} else {
var _ = cljs.core.first(s__26954__$2);
return cljs.core.cons(reagent.core.atom.cljs$core$IFn$_invoke$arity$1((2)),simulation$iter__26953(cljs.core.rest(s__26954__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4611__auto__(cljs.core.range.cljs$core$IFn$_invoke$arity$1((5)));
})());
}
cljs.core.reset_BANG_((simulation.process_times.cljs$core$IFn$_invoke$arity$1 ? simulation.process_times.cljs$core$IFn$_invoke$arity$1((1)) : simulation.process_times.call(null,(1))),(4));
cljs.core.reset_BANG_((simulation.process_times.cljs$core$IFn$_invoke$arity$1 ? simulation.process_times.cljs$core$IFn$_invoke$arity$1((2)) : simulation.process_times.call(null,(2))),(6));
if((typeof simulation !== 'undefined') && (typeof simulation.readonly !== 'undefined')){
} else {
simulation.readonly = reagent.core.atom.cljs$core$IFn$_invoke$arity$1(false);
}
if((typeof simulation !== 'undefined') && (typeof simulation.total_process_time !== 'undefined')){
} else {
simulation.total_process_time = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.total_lead_time !== 'undefined')){
} else {
simulation.total_lead_time = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.skovhygge_input !== 'undefined')){
} else {
simulation.skovhygge_input = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.skov_output !== 'undefined')){
} else {
simulation.skov_output = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.item_1 !== 'undefined')){
} else {
simulation.item_1 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.item_2 !== 'undefined')){
} else {
simulation.item_2 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.item_3 !== 'undefined')){
} else {
simulation.item_3 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.item_4 !== 'undefined')){
} else {
simulation.item_4 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.item_5 !== 'undefined')){
} else {
simulation.item_5 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((0));
}
if((typeof simulation !== 'undefined') && (typeof simulation.lead_time_1 !== 'undefined')){
} else {
simulation.lead_time_1 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1("-");
}
if((typeof simulation !== 'undefined') && (typeof simulation.lead_time_2 !== 'undefined')){
} else {
simulation.lead_time_2 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1("-");
}
if((typeof simulation !== 'undefined') && (typeof simulation.lead_time_3 !== 'undefined')){
} else {
simulation.lead_time_3 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1("-");
}
if((typeof simulation !== 'undefined') && (typeof simulation.lead_time_4 !== 'undefined')){
} else {
simulation.lead_time_4 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1("-");
}
if((typeof simulation !== 'undefined') && (typeof simulation.lead_time_5 !== 'undefined')){
} else {
simulation.lead_time_5 = reagent.core.atom.cljs$core$IFn$_invoke$arity$1("-");
}
if((typeof simulation !== 'undefined') && (typeof simulation.ws_ids !== 'undefined')){
} else {
simulation.ws_ids = new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, ["ws1","ws2","ws3","ws4"], null);
}
simulation.run = (function simulation$run(){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(processtime.process_time_skovhugger,cljs.core.dec);

skovhugger.tree_felling((cljs.core.count(cljs.core.deref(cljs.core.first(simulation.queues))) < (12)),processtime.process_time_skovhugger,cljs.core.first(simulation.queues),cljs.core.deref(simulation.sim_time),processtime.process_time_skovhugger_original);

var seq__26957_26981 = cljs.core.seq(cljs.core.range.cljs$core$IFn$_invoke$arity$1((4)));
var chunk__26958_26982 = null;
var count__26959_26983 = (0);
var i__26960_26984 = (0);
while(true){
if((i__26960_26984 < count__26959_26983)){
var i_26985 = chunk__26958_26982.cljs$core$IIndexed$_nth$arity$2(null,i__26960_26984);
var map__26967_26986 = workstation.run(cljs.core.deref(simulation.sim_time),(simulation.ws_ids.cljs$core$IFn$_invoke$arity$1 ? simulation.ws_ids.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.ws_ids.call(null,i_26985)),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"from-queue","from-queue",1113830756),cljs.core.deref((simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.queues.call(null,i_26985))),new cljs.core.Keyword(null,"to-queue","to-queue",9014509),cljs.core.deref((function (){var G__26968 = (i_26985 + (1));
return (simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(G__26968) : simulation.queues.call(null,G__26968));
})()),new cljs.core.Keyword(null,"process-time","process-time",2113882878),cljs.core.deref((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1(i_26985) : processtime.process_times.call(null,i_26985))),new cljs.core.Keyword(null,"current-time","current-time",-1609407134),cljs.core.deref((simulation.current_times.cljs$core$IFn$_invoke$arity$1 ? simulation.current_times.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.current_times.call(null,i_26985))),new cljs.core.Keyword(null,"current-log","current-log",472329498),cljs.core.deref((simulation.current_logs.cljs$core$IFn$_invoke$arity$1 ? simulation.current_logs.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.current_logs.call(null,i_26985)))], null));
var map__26967_26987__$1 = cljs.core.__destructure_map(map__26967_26986);
var from_queue_26988 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26967_26987__$1,new cljs.core.Keyword(null,"from-queue","from-queue",1113830756));
var to_queue_26989 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26967_26987__$1,new cljs.core.Keyword(null,"to-queue","to-queue",9014509));
var current_time_26990 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26967_26987__$1,new cljs.core.Keyword(null,"current-time","current-time",-1609407134));
var current_log_26991 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26967_26987__$1,new cljs.core.Keyword(null,"current-log","current-log",472329498));
cljs.core.reset_BANG_((simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.queues.call(null,i_26985)),from_queue_26988);

cljs.core.reset_BANG_((function (){var G__26969 = (i_26985 + (1));
return (simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(G__26969) : simulation.queues.call(null,G__26969));
})(),to_queue_26989);

cljs.core.reset_BANG_((simulation.current_times.cljs$core$IFn$_invoke$arity$1 ? simulation.current_times.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.current_times.call(null,i_26985)),current_time_26990);

cljs.core.reset_BANG_((simulation.current_logs.cljs$core$IFn$_invoke$arity$1 ? simulation.current_logs.cljs$core$IFn$_invoke$arity$1(i_26985) : simulation.current_logs.call(null,i_26985)),current_log_26991);


var G__26992 = seq__26957_26981;
var G__26993 = chunk__26958_26982;
var G__26994 = count__26959_26983;
var G__26995 = (i__26960_26984 + (1));
seq__26957_26981 = G__26992;
chunk__26958_26982 = G__26993;
count__26959_26983 = G__26994;
i__26960_26984 = G__26995;
continue;
} else {
var temp__5753__auto___26996 = cljs.core.seq(seq__26957_26981);
if(temp__5753__auto___26996){
var seq__26957_26997__$1 = temp__5753__auto___26996;
if(cljs.core.chunked_seq_QMARK_(seq__26957_26997__$1)){
var c__4638__auto___26998 = cljs.core.chunk_first(seq__26957_26997__$1);
var G__26999 = cljs.core.chunk_rest(seq__26957_26997__$1);
var G__27000 = c__4638__auto___26998;
var G__27001 = cljs.core.count(c__4638__auto___26998);
var G__27002 = (0);
seq__26957_26981 = G__26999;
chunk__26958_26982 = G__27000;
count__26959_26983 = G__27001;
i__26960_26984 = G__27002;
continue;
} else {
var i_27003 = cljs.core.first(seq__26957_26997__$1);
var map__26970_27004 = workstation.run(cljs.core.deref(simulation.sim_time),(simulation.ws_ids.cljs$core$IFn$_invoke$arity$1 ? simulation.ws_ids.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.ws_ids.call(null,i_27003)),new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"from-queue","from-queue",1113830756),cljs.core.deref((simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.queues.call(null,i_27003))),new cljs.core.Keyword(null,"to-queue","to-queue",9014509),cljs.core.deref((function (){var G__26971 = (i_27003 + (1));
return (simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(G__26971) : simulation.queues.call(null,G__26971));
})()),new cljs.core.Keyword(null,"process-time","process-time",2113882878),cljs.core.deref((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1(i_27003) : processtime.process_times.call(null,i_27003))),new cljs.core.Keyword(null,"current-time","current-time",-1609407134),cljs.core.deref((simulation.current_times.cljs$core$IFn$_invoke$arity$1 ? simulation.current_times.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.current_times.call(null,i_27003))),new cljs.core.Keyword(null,"current-log","current-log",472329498),cljs.core.deref((simulation.current_logs.cljs$core$IFn$_invoke$arity$1 ? simulation.current_logs.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.current_logs.call(null,i_27003)))], null));
var map__26970_27005__$1 = cljs.core.__destructure_map(map__26970_27004);
var from_queue_27006 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26970_27005__$1,new cljs.core.Keyword(null,"from-queue","from-queue",1113830756));
var to_queue_27007 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26970_27005__$1,new cljs.core.Keyword(null,"to-queue","to-queue",9014509));
var current_time_27008 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26970_27005__$1,new cljs.core.Keyword(null,"current-time","current-time",-1609407134));
var current_log_27009 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26970_27005__$1,new cljs.core.Keyword(null,"current-log","current-log",472329498));
cljs.core.reset_BANG_((simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.queues.call(null,i_27003)),from_queue_27006);

cljs.core.reset_BANG_((function (){var G__26972 = (i_27003 + (1));
return (simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(G__26972) : simulation.queues.call(null,G__26972));
})(),to_queue_27007);

cljs.core.reset_BANG_((simulation.current_times.cljs$core$IFn$_invoke$arity$1 ? simulation.current_times.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.current_times.call(null,i_27003)),current_time_27008);

cljs.core.reset_BANG_((simulation.current_logs.cljs$core$IFn$_invoke$arity$1 ? simulation.current_logs.cljs$core$IFn$_invoke$arity$1(i_27003) : simulation.current_logs.call(null,i_27003)),current_log_27009);


var G__27010 = cljs.core.next(seq__26957_26997__$1);
var G__27011 = null;
var G__27012 = (0);
var G__27013 = (0);
seq__26957_26981 = G__27010;
chunk__26958_26982 = G__27011;
count__26959_26983 = G__27012;
i__26960_26984 = G__27013;
continue;
}
} else {
}
}
break;
}

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$2(simulation.sim_time,cljs.core.inc);
});
simulation.start = (function simulation$start(){
cljs.core.reset_BANG_(simulation.paused_QMARK_,false);

return cljs.core.reset_BANG_(simulation.interval,setInterval(simulation.run,(1000)));
});
simulation.pause = (function simulation$pause(){
cljs.core.reset_BANG_(simulation.paused_QMARK_,true);

return clearInterval(cljs.core.deref(simulation.interval));
});
simulation.pause_btn = (function simulation$pause_btn(){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"input.button.start-button","input.button.start-button",904215465),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"type","type",1174270348),"button",new cljs.core.Keyword(null,"value","value",305978217),(cljs.core.truth_(cljs.core.deref(simulation.paused_QMARK_))?"Start":"Pause"),new cljs.core.Keyword(null,"on-click","on-click",1632826543),(function (){
if(cljs.core.truth_(cljs.core.deref(simulation.paused_QMARK_))){
return simulation.start();
} else {
return simulation.pause();
}
})], null)], null);
});
simulation.time_display = (function simulation$time_display(){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"div.timer","div.timer",396383019),cljs.core.deref(simulation.sim_time)], null);
});

//# sourceMappingURL=simulation.js.map
