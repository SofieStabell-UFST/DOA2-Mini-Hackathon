goog.provide('processtime');
if((typeof processtime !== 'undefined') && (typeof processtime.process_times !== 'undefined')){
} else {
processtime.process_times = cljs.core.vec((function (){var iter__4611__auto__ = (function processtime$iter__26574(s__26575){
return (new cljs.core.LazySeq(null,(function (){
var s__26575__$1 = s__26575;
while(true){
var temp__5753__auto__ = cljs.core.seq(s__26575__$1);
if(temp__5753__auto__){
var s__26575__$2 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(s__26575__$2)){
var c__4609__auto__ = cljs.core.chunk_first(s__26575__$2);
var size__4610__auto__ = cljs.core.count(c__4609__auto__);
var b__26577 = cljs.core.chunk_buffer(size__4610__auto__);
if((function (){var i__26576 = (0);
while(true){
if((i__26576 < size__4610__auto__)){
var _ = cljs.core._nth(c__4609__auto__,i__26576);
cljs.core.chunk_append(b__26577,reagent.core.atom.cljs$core$IFn$_invoke$arity$1((2)));

var G__26578 = (i__26576 + (1));
i__26576 = G__26578;
continue;
} else {
return true;
}
break;
}
})()){
return cljs.core.chunk_cons(cljs.core.chunk(b__26577),processtime$iter__26574(cljs.core.chunk_rest(s__26575__$2)));
} else {
return cljs.core.chunk_cons(cljs.core.chunk(b__26577),null);
}
} else {
var _ = cljs.core.first(s__26575__$2);
return cljs.core.cons(reagent.core.atom.cljs$core$IFn$_invoke$arity$1((2)),processtime$iter__26574(cljs.core.rest(s__26575__$2)));
}
} else {
return null;
}
break;
}
}),null,null));
});
return iter__4611__auto__(cljs.core.range.cljs$core$IFn$_invoke$arity$1((5)));
})());
}
processtime.update_process_time1 = (function processtime$update_process_time1(new_process_time){
return cljs.core.reset_BANG_((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1((0)) : processtime.process_times.call(null,(0))),new_process_time);
});
if((typeof processtime !== 'undefined') && (typeof processtime.process_time_skovhugger_original !== 'undefined')){
} else {
processtime.process_time_skovhugger_original = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((1));
}
if((typeof processtime !== 'undefined') && (typeof processtime.process_time_skovhugger !== 'undefined')){
} else {
processtime.process_time_skovhugger = reagent.core.atom.cljs$core$IFn$_invoke$arity$1((1));
}
processtime.update_process_time2 = (function processtime$update_process_time2(new_process_time){
return cljs.core.reset_BANG_((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1((1)) : processtime.process_times.call(null,(1))),new_process_time);
});
processtime.update_process_time3 = (function processtime$update_process_time3(new_process_time){
return cljs.core.reset_BANG_((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1((2)) : processtime.process_times.call(null,(2))),new_process_time);
});
processtime.update_process_time4 = (function processtime$update_process_time4(new_process_time){
return cljs.core.reset_BANG_((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1((3)) : processtime.process_times.call(null,(3))),new_process_time);
});
processtime.update_process_time5 = (function processtime$update_process_time5(new_process_time){
return cljs.core.reset_BANG_((processtime.process_times.cljs$core$IFn$_invoke$arity$1 ? processtime.process_times.cljs$core$IFn$_invoke$arity$1((4)) : processtime.process_times.call(null,(4))),new_process_time);
});
processtime.update_skovhugger_process_time = (function processtime$update_skovhugger_process_time(new_skovhugger_process_time){
cljs.core.reset_BANG_(processtime.process_time_skovhugger_original,new_skovhugger_process_time);

return cljs.core.reset_BANG_(processtime.process_time_skovhugger,new_skovhugger_process_time);
});

//# sourceMappingURL=processtime.js.map
