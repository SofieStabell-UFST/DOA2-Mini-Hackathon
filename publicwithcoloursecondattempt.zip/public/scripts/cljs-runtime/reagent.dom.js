goog.provide('reagent.dom');
var module$node_modules$react_dom$index=shadow.js.require("module$node_modules$react_dom$index", {});
if((typeof reagent !== 'undefined') && (typeof reagent.dom !== 'undefined') && (typeof reagent.dom.roots !== 'undefined')){
} else {
reagent.dom.roots = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(cljs.core.PersistentArrayMap.EMPTY);
}
reagent.dom.unmount_comp = (function reagent$dom$unmount_comp(container){
cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(reagent.dom.roots,cljs.core.dissoc,container);

return module$node_modules$react_dom$index.unmountComponentAtNode(container);
});
reagent.dom.render_comp = (function reagent$dom$render_comp(comp,container,callback){
var _STAR_always_update_STAR__orig_val__36462 = reagent.impl.util._STAR_always_update_STAR_;
var _STAR_always_update_STAR__temp_val__36463 = true;
(reagent.impl.util._STAR_always_update_STAR_ = _STAR_always_update_STAR__temp_val__36463);

try{return module$node_modules$react_dom$index.render((comp.cljs$core$IFn$_invoke$arity$0 ? comp.cljs$core$IFn$_invoke$arity$0() : comp.call(null)),container,(function (){
var _STAR_always_update_STAR__orig_val__36465 = reagent.impl.util._STAR_always_update_STAR_;
var _STAR_always_update_STAR__temp_val__36466 = false;
(reagent.impl.util._STAR_always_update_STAR_ = _STAR_always_update_STAR__temp_val__36466);

try{cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$4(reagent.dom.roots,cljs.core.assoc,container,comp);

reagent.impl.batching.flush_after_render();

if((!((callback == null)))){
return (callback.cljs$core$IFn$_invoke$arity$0 ? callback.cljs$core$IFn$_invoke$arity$0() : callback.call(null));
} else {
return null;
}
}finally {(reagent.impl.util._STAR_always_update_STAR_ = _STAR_always_update_STAR__orig_val__36465);
}}));
}finally {(reagent.impl.util._STAR_always_update_STAR_ = _STAR_always_update_STAR__orig_val__36462);
}});
reagent.dom.re_render_component = (function reagent$dom$re_render_component(comp,container){
return reagent.dom.render_comp(comp,container,null);
});
/**
 * Render a Reagent component into the DOM. The first argument may be
 *   either a vector (using Reagent's Hiccup syntax), or a React element.
 *   The second argument should be a DOM node.
 * 
 *   Optionally takes a callback that is called when the component is in place.
 * 
 *   Returns the mounted component instance.
 */
reagent.dom.render = (function reagent$dom$render(var_args){
var G__36477 = arguments.length;
switch (G__36477) {
case 2:
return reagent.dom.render.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return reagent.dom.render.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(reagent.dom.render.cljs$core$IFn$_invoke$arity$2 = (function (comp,container){
return reagent.dom.render.cljs$core$IFn$_invoke$arity$3(comp,container,reagent.impl.template.default_compiler);
}));

(reagent.dom.render.cljs$core$IFn$_invoke$arity$3 = (function (comp,container,callback_or_compiler){
reagent.ratom.flush_BANG_();

var vec__36482 = ((cljs.core.fn_QMARK_(callback_or_compiler))?new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [reagent.impl.template.default_compiler,callback_or_compiler], null):new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [callback_or_compiler,new cljs.core.Keyword(null,"callback","callback",-705136228).cljs$core$IFn$_invoke$arity$1(callback_or_compiler)], null));
var compiler = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36482,(0),null);
var callback = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36482,(1),null);
var f = (function (){
return reagent.impl.protocols.as_element(compiler,((cljs.core.fn_QMARK_(comp))?(comp.cljs$core$IFn$_invoke$arity$0 ? comp.cljs$core$IFn$_invoke$arity$0() : comp.call(null)):comp));
});
return reagent.dom.render_comp(f,container,callback);
}));

(reagent.dom.render.cljs$lang$maxFixedArity = 3);

/**
 * Remove a component from the given DOM node.
 */
reagent.dom.unmount_component_at_node = (function reagent$dom$unmount_component_at_node(container){
return reagent.dom.unmount_comp(container);
});
/**
 * Returns the root DOM node of a mounted component.
 */
reagent.dom.dom_node = (function reagent$dom$dom_node(this$){
return module$node_modules$react_dom$index.findDOMNode(this$);
});
/**
 * Force re-rendering of all mounted Reagent components. This is
 *   probably only useful in a development environment, when you want to
 *   update components in response to some dynamic changes to code.
 * 
 *   Note that force-update-all may not update root components. This
 *   happens if a component 'foo' is mounted with `(render [foo])` (since
 *   functions are passed by value, and not by reference, in
 *   ClojureScript). To get around this you'll have to introduce a layer
 *   of indirection, for example by using `(render [#'foo])` instead.
 */
reagent.dom.force_update_all = (function reagent$dom$force_update_all(){
reagent.ratom.flush_BANG_();

var seq__36494_36525 = cljs.core.seq(cljs.core.deref(reagent.dom.roots));
var chunk__36495_36526 = null;
var count__36496_36527 = (0);
var i__36497_36528 = (0);
while(true){
if((i__36497_36528 < count__36496_36527)){
var vec__36515_36529 = chunk__36495_36526.cljs$core$IIndexed$_nth$arity$2(null,i__36497_36528);
var container_36530 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36515_36529,(0),null);
var comp_36531 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36515_36529,(1),null);
reagent.dom.re_render_component(comp_36531,container_36530);


var G__36532 = seq__36494_36525;
var G__36533 = chunk__36495_36526;
var G__36534 = count__36496_36527;
var G__36535 = (i__36497_36528 + (1));
seq__36494_36525 = G__36532;
chunk__36495_36526 = G__36533;
count__36496_36527 = G__36534;
i__36497_36528 = G__36535;
continue;
} else {
var temp__5753__auto___36536 = cljs.core.seq(seq__36494_36525);
if(temp__5753__auto___36536){
var seq__36494_36537__$1 = temp__5753__auto___36536;
if(cljs.core.chunked_seq_QMARK_(seq__36494_36537__$1)){
var c__4638__auto___36538 = cljs.core.chunk_first(seq__36494_36537__$1);
var G__36539 = cljs.core.chunk_rest(seq__36494_36537__$1);
var G__36540 = c__4638__auto___36538;
var G__36541 = cljs.core.count(c__4638__auto___36538);
var G__36542 = (0);
seq__36494_36525 = G__36539;
chunk__36495_36526 = G__36540;
count__36496_36527 = G__36541;
i__36497_36528 = G__36542;
continue;
} else {
var vec__36520_36543 = cljs.core.first(seq__36494_36537__$1);
var container_36544 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36520_36543,(0),null);
var comp_36545 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__36520_36543,(1),null);
reagent.dom.re_render_component(comp_36545,container_36544);


var G__36546 = cljs.core.next(seq__36494_36537__$1);
var G__36547 = null;
var G__36548 = (0);
var G__36549 = (0);
seq__36494_36525 = G__36546;
chunk__36495_36526 = G__36547;
count__36496_36527 = G__36548;
i__36497_36528 = G__36549;
continue;
}
} else {
}
}
break;
}

return reagent.impl.batching.flush_after_render();
});

//# sourceMappingURL=reagent.dom.js.map
