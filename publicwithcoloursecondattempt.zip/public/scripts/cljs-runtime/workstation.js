goog.provide('workstation');
if((typeof workstation !== 'undefined') && (typeof workstation.QUEUE_MAX_COUNT !== 'undefined')){
} else {
workstation.QUEUE_MAX_COUNT = (12);
}
workstation.pull = (function workstation$pull(sim_time,ws_id,p__26580){
var map__26581 = p__26580;
var map__26581__$1 = cljs.core.__destructure_map(map__26581);
var state = map__26581__$1;
var from_queue = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26581__$1,new cljs.core.Keyword(null,"from-queue","from-queue",1113830756));
if(cljs.core.seq(from_queue)){
return cljs.core.update.cljs$core$IFn$_invoke$arity$3(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(state,new cljs.core.Keyword(null,"current-log","current-log",472329498),treetrunkgenerator.stample_start_time(cljs.core.last(from_queue),ws_id,sim_time)),new cljs.core.Keyword(null,"current-time","current-time",-1609407134),(1)),new cljs.core.Keyword(null,"from-queue","from-queue",1113830756),(function (v){
return cljs.core.subvec.cljs$core$IFn$_invoke$arity$3(v,(0),(cljs.core.count(v) - (1)));
}));
} else {
return state;
}
});
workstation.push = (function workstation$push(sim_time,ws_id,p__26582){
var map__26583 = p__26582;
var map__26583__$1 = cljs.core.__destructure_map(map__26583);
var state = map__26583__$1;
var to_queue = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26583__$1,new cljs.core.Keyword(null,"to-queue","to-queue",9014509));
var current_log = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26583__$1,new cljs.core.Keyword(null,"current-log","current-log",472329498));
if((cljs.core.count(to_queue) < workstation.QUEUE_MAX_COUNT)){
return cljs.core.update.cljs$core$IFn$_invoke$arity$4(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(state,new cljs.core.Keyword(null,"current-log","current-log",472329498),null),new cljs.core.Keyword(null,"current-time","current-time",-1609407134),(0)),new cljs.core.Keyword(null,"to-queue","to-queue",9014509),cljs.core.conj,treetrunkgenerator.stample_end_time(current_log,ws_id,sim_time));
} else {
return state;
}
});
workstation.run = (function workstation$run(sim_time,ws_id,p__26584){
var map__26585 = p__26584;
var map__26585__$1 = cljs.core.__destructure_map(map__26585);
var state = map__26585__$1;
var process_time = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26585__$1,new cljs.core.Keyword(null,"process-time","process-time",2113882878));
var from_queue = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26585__$1,new cljs.core.Keyword(null,"from-queue","from-queue",1113830756));
var to_queue = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26585__$1,new cljs.core.Keyword(null,"to-queue","to-queue",9014509));
var current_time = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26585__$1,new cljs.core.Keyword(null,"current-time","current-time",-1609407134));
var current_log = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26585__$1,new cljs.core.Keyword(null,"current-log","current-log",472329498));
if(cljs.core.truth_((function (){var and__4210__auto__ = current_log;
if(cljs.core.truth_(and__4210__auto__)){
return (current_time < process_time);
} else {
return and__4210__auto__;
}
})())){
return cljs.core.update.cljs$core$IFn$_invoke$arity$3(state,new cljs.core.Keyword(null,"current-time","current-time",-1609407134),cljs.core.inc);
} else {
if(cljs.core.truth_(current_log)){
var map__26586 = workstation.push(sim_time,ws_id,state);
var map__26586__$1 = cljs.core.__destructure_map(map__26586);
var state__$1 = map__26586__$1;
var current_log__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__26586__$1,new cljs.core.Keyword(null,"current-log","current-log",472329498));
if(cljs.core.not(current_log__$1)){
return workstation.pull(sim_time,ws_id,state__$1);
} else {
return state__$1;
}
} else {
return workstation.pull(sim_time,ws_id,state);
}
}
});

//# sourceMappingURL=workstation.js.map
