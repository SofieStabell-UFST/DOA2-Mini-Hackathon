goog.provide('skovhugger');
skovhugger.tree_felling = (function skovhugger$tree_felling(ws1_free,skovhugger_process_time,queue1,sim_time,skovhugger_process_time_original){
if(cljs.core.truth_(ws1_free)){
var tree_trunk = treetrunkgenerator.create_tree_trunk(sim_time);
var _ = (((cljs.core.deref(skovhugger_process_time) <= (0)))?(function (){
cljs.core.reset_BANG_(skovhugger_process_time,cljs.core.deref(skovhugger_process_time_original));

return cljs.core.swap_BANG_.cljs$core$IFn$_invoke$arity$3(queue1,cljs.core.conj,tree_trunk);
})()
:null);
return null;
} else {
return null;
}
});

//# sourceMappingURL=skovhugger.js.map
