goog.provide('cljs.repl');
cljs.repl.print_doc = (function cljs$repl$print_doc(p__34998){
var map__34999 = p__34998;
var map__34999__$1 = cljs.core.__destructure_map(map__34999);
var m = map__34999__$1;
var n = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34999__$1,new cljs.core.Keyword(null,"ns","ns",441598760));
var nm = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__34999__$1,new cljs.core.Keyword(null,"name","name",1843675177));
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["-------------------------"], 0));

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([(function (){var or__4212__auto__ = new cljs.core.Keyword(null,"spec","spec",347520401).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return [(function (){var temp__5753__auto__ = new cljs.core.Keyword(null,"ns","ns",441598760).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(temp__5753__auto__)){
var ns = temp__5753__auto__;
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(ns),"/"].join('');
} else {
return null;
}
})(),cljs.core.str.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(m))].join('');
}
})()], 0));

if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["Protocol"], 0));
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"forms","forms",2045992350).cljs$core$IFn$_invoke$arity$1(m))){
var seq__35001_35255 = cljs.core.seq(new cljs.core.Keyword(null,"forms","forms",2045992350).cljs$core$IFn$_invoke$arity$1(m));
var chunk__35002_35256 = null;
var count__35003_35257 = (0);
var i__35004_35258 = (0);
while(true){
if((i__35004_35258 < count__35003_35257)){
var f_35259 = chunk__35002_35256.cljs$core$IIndexed$_nth$arity$2(null,i__35004_35258);
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["  ",f_35259], 0));


var G__35260 = seq__35001_35255;
var G__35261 = chunk__35002_35256;
var G__35262 = count__35003_35257;
var G__35263 = (i__35004_35258 + (1));
seq__35001_35255 = G__35260;
chunk__35002_35256 = G__35261;
count__35003_35257 = G__35262;
i__35004_35258 = G__35263;
continue;
} else {
var temp__5753__auto___35264 = cljs.core.seq(seq__35001_35255);
if(temp__5753__auto___35264){
var seq__35001_35265__$1 = temp__5753__auto___35264;
if(cljs.core.chunked_seq_QMARK_(seq__35001_35265__$1)){
var c__4638__auto___35266 = cljs.core.chunk_first(seq__35001_35265__$1);
var G__35267 = cljs.core.chunk_rest(seq__35001_35265__$1);
var G__35268 = c__4638__auto___35266;
var G__35269 = cljs.core.count(c__4638__auto___35266);
var G__35270 = (0);
seq__35001_35255 = G__35267;
chunk__35002_35256 = G__35268;
count__35003_35257 = G__35269;
i__35004_35258 = G__35270;
continue;
} else {
var f_35271 = cljs.core.first(seq__35001_35265__$1);
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["  ",f_35271], 0));


var G__35272 = cljs.core.next(seq__35001_35265__$1);
var G__35273 = null;
var G__35274 = (0);
var G__35275 = (0);
seq__35001_35255 = G__35272;
chunk__35002_35256 = G__35273;
count__35003_35257 = G__35274;
i__35004_35258 = G__35275;
continue;
}
} else {
}
}
break;
}
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"arglists","arglists",1661989754).cljs$core$IFn$_invoke$arity$1(m))){
var arglists_35276 = new cljs.core.Keyword(null,"arglists","arglists",1661989754).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_((function (){var or__4212__auto__ = new cljs.core.Keyword(null,"macro","macro",-867863404).cljs$core$IFn$_invoke$arity$1(m);
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return new cljs.core.Keyword(null,"repl-special-function","repl-special-function",1262603725).cljs$core$IFn$_invoke$arity$1(m);
}
})())){
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([arglists_35276], 0));
} else {
cljs.core.prn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.first(arglists_35276)))?cljs.core.second(arglists_35276):arglists_35276)], 0));
}
} else {
}
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"special-form","special-form",-1326536374).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["Special Form"], 0));

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",new cljs.core.Keyword(null,"doc","doc",1913296891).cljs$core$IFn$_invoke$arity$1(m)], 0));

if(cljs.core.contains_QMARK_(m,new cljs.core.Keyword(null,"url","url",276297046))){
if(cljs.core.truth_(new cljs.core.Keyword(null,"url","url",276297046).cljs$core$IFn$_invoke$arity$1(m))){
return cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([["\n  Please see http://clojure.org/",cljs.core.str.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"url","url",276297046).cljs$core$IFn$_invoke$arity$1(m))].join('')], 0));
} else {
return null;
}
} else {
return cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([["\n  Please see http://clojure.org/special_forms#",cljs.core.str.cljs$core$IFn$_invoke$arity$1(new cljs.core.Keyword(null,"name","name",1843675177).cljs$core$IFn$_invoke$arity$1(m))].join('')], 0));
}
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"macro","macro",-867863404).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["Macro"], 0));
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"spec","spec",347520401).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["Spec"], 0));
} else {
}

if(cljs.core.truth_(new cljs.core.Keyword(null,"repl-special-function","repl-special-function",1262603725).cljs$core$IFn$_invoke$arity$1(m))){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["REPL Special Function"], 0));
} else {
}

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",new cljs.core.Keyword(null,"doc","doc",1913296891).cljs$core$IFn$_invoke$arity$1(m)], 0));

if(cljs.core.truth_(new cljs.core.Keyword(null,"protocol","protocol",652470118).cljs$core$IFn$_invoke$arity$1(m))){
var seq__35013_35277 = cljs.core.seq(new cljs.core.Keyword(null,"methods","methods",453930866).cljs$core$IFn$_invoke$arity$1(m));
var chunk__35014_35278 = null;
var count__35015_35279 = (0);
var i__35016_35280 = (0);
while(true){
if((i__35016_35280 < count__35015_35279)){
var vec__35031_35281 = chunk__35014_35278.cljs$core$IIndexed$_nth$arity$2(null,i__35016_35280);
var name_35282 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35031_35281,(0),null);
var map__35034_35283 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35031_35281,(1),null);
var map__35034_35284__$1 = cljs.core.__destructure_map(map__35034_35283);
var doc_35285 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35034_35284__$1,new cljs.core.Keyword(null,"doc","doc",1913296891));
var arglists_35286 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35034_35284__$1,new cljs.core.Keyword(null,"arglists","arglists",1661989754));
cljs.core.println();

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",name_35282], 0));

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",arglists_35286], 0));

if(cljs.core.truth_(doc_35285)){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",doc_35285], 0));
} else {
}


var G__35294 = seq__35013_35277;
var G__35295 = chunk__35014_35278;
var G__35296 = count__35015_35279;
var G__35297 = (i__35016_35280 + (1));
seq__35013_35277 = G__35294;
chunk__35014_35278 = G__35295;
count__35015_35279 = G__35296;
i__35016_35280 = G__35297;
continue;
} else {
var temp__5753__auto___35298 = cljs.core.seq(seq__35013_35277);
if(temp__5753__auto___35298){
var seq__35013_35299__$1 = temp__5753__auto___35298;
if(cljs.core.chunked_seq_QMARK_(seq__35013_35299__$1)){
var c__4638__auto___35310 = cljs.core.chunk_first(seq__35013_35299__$1);
var G__35311 = cljs.core.chunk_rest(seq__35013_35299__$1);
var G__35312 = c__4638__auto___35310;
var G__35313 = cljs.core.count(c__4638__auto___35310);
var G__35314 = (0);
seq__35013_35277 = G__35311;
chunk__35014_35278 = G__35312;
count__35015_35279 = G__35313;
i__35016_35280 = G__35314;
continue;
} else {
var vec__35038_35316 = cljs.core.first(seq__35013_35299__$1);
var name_35317 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35038_35316,(0),null);
var map__35041_35318 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35038_35316,(1),null);
var map__35041_35319__$1 = cljs.core.__destructure_map(map__35041_35318);
var doc_35320 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35041_35319__$1,new cljs.core.Keyword(null,"doc","doc",1913296891));
var arglists_35321 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35041_35319__$1,new cljs.core.Keyword(null,"arglists","arglists",1661989754));
cljs.core.println();

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",name_35317], 0));

cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",arglists_35321], 0));

if(cljs.core.truth_(doc_35320)){
cljs.core.println.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([" ",doc_35320], 0));
} else {
}


var G__35322 = cljs.core.next(seq__35013_35299__$1);
var G__35323 = null;
var G__35324 = (0);
var G__35325 = (0);
seq__35013_35277 = G__35322;
chunk__35014_35278 = G__35323;
count__35015_35279 = G__35324;
i__35016_35280 = G__35325;
continue;
}
} else {
}
}
break;
}
} else {
}

if(cljs.core.truth_(n)){
var temp__5753__auto__ = cljs.spec.alpha.get_spec(cljs.core.symbol.cljs$core$IFn$_invoke$arity$2(cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.ns_name(n)),cljs.core.name(nm)));
if(cljs.core.truth_(temp__5753__auto__)){
var fnspec = temp__5753__auto__;
cljs.core.print.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2(["Spec"], 0));

var seq__35043 = cljs.core.seq(new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"args","args",1315556576),new cljs.core.Keyword(null,"ret","ret",-468222814),new cljs.core.Keyword(null,"fn","fn",-1175266204)], null));
var chunk__35044 = null;
var count__35045 = (0);
var i__35046 = (0);
while(true){
if((i__35046 < count__35045)){
var role = chunk__35044.cljs$core$IIndexed$_nth$arity$2(null,i__35046);
var temp__5753__auto___35330__$1 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(fnspec,role);
if(cljs.core.truth_(temp__5753__auto___35330__$1)){
var spec_35332 = temp__5753__auto___35330__$1;
cljs.core.print.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([["\n ",cljs.core.name(role),":"].join(''),cljs.spec.alpha.describe(spec_35332)], 0));
} else {
}


var G__35334 = seq__35043;
var G__35335 = chunk__35044;
var G__35336 = count__35045;
var G__35337 = (i__35046 + (1));
seq__35043 = G__35334;
chunk__35044 = G__35335;
count__35045 = G__35336;
i__35046 = G__35337;
continue;
} else {
var temp__5753__auto____$1 = cljs.core.seq(seq__35043);
if(temp__5753__auto____$1){
var seq__35043__$1 = temp__5753__auto____$1;
if(cljs.core.chunked_seq_QMARK_(seq__35043__$1)){
var c__4638__auto__ = cljs.core.chunk_first(seq__35043__$1);
var G__35338 = cljs.core.chunk_rest(seq__35043__$1);
var G__35339 = c__4638__auto__;
var G__35340 = cljs.core.count(c__4638__auto__);
var G__35341 = (0);
seq__35043 = G__35338;
chunk__35044 = G__35339;
count__35045 = G__35340;
i__35046 = G__35341;
continue;
} else {
var role = cljs.core.first(seq__35043__$1);
var temp__5753__auto___35342__$2 = cljs.core.get.cljs$core$IFn$_invoke$arity$2(fnspec,role);
if(cljs.core.truth_(temp__5753__auto___35342__$2)){
var spec_35343 = temp__5753__auto___35342__$2;
cljs.core.print.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([["\n ",cljs.core.name(role),":"].join(''),cljs.spec.alpha.describe(spec_35343)], 0));
} else {
}


var G__35344 = cljs.core.next(seq__35043__$1);
var G__35345 = null;
var G__35346 = (0);
var G__35347 = (0);
seq__35043 = G__35344;
chunk__35044 = G__35345;
count__35045 = G__35346;
i__35046 = G__35347;
continue;
}
} else {
return null;
}
}
break;
}
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Constructs a data representation for a Error with keys:
 *  :cause - root cause message
 *  :phase - error phase
 *  :via - cause chain, with cause keys:
 *           :type - exception class symbol
 *           :message - exception message
 *           :data - ex-data
 *           :at - top stack element
 *  :trace - root cause stack elements
 */
cljs.repl.Error__GT_map = (function cljs$repl$Error__GT_map(o){
var base = (function (t){
return cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"type","type",1174270348),(((t instanceof cljs.core.ExceptionInfo))?new cljs.core.Symbol("cljs.core","ExceptionInfo","cljs.core/ExceptionInfo",701839050,null):(((t instanceof Error))?cljs.core.symbol.cljs$core$IFn$_invoke$arity$2("js",t.name):null
))], null),(function (){var temp__5753__auto__ = cljs.core.ex_message(t);
if(cljs.core.truth_(temp__5753__auto__)){
var msg = temp__5753__auto__;
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"message","message",-406056002),msg], null);
} else {
return null;
}
})(),(function (){var temp__5753__auto__ = cljs.core.ex_data(t);
if(cljs.core.truth_(temp__5753__auto__)){
var ed = temp__5753__auto__;
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"data","data",-232669377),ed], null);
} else {
return null;
}
})()], 0));
});
var via = (function (){var via = cljs.core.PersistentVector.EMPTY;
var t = o;
while(true){
if(cljs.core.truth_(t)){
var G__35351 = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(via,t);
var G__35352 = cljs.core.ex_cause(t);
via = G__35351;
t = G__35352;
continue;
} else {
return via;
}
break;
}
})();
var root = cljs.core.peek(via);
return cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"via","via",-1904457336),cljs.core.vec(cljs.core.map.cljs$core$IFn$_invoke$arity$2(base,via)),new cljs.core.Keyword(null,"trace","trace",-1082747415),null], null),(function (){var temp__5753__auto__ = cljs.core.ex_message(root);
if(cljs.core.truth_(temp__5753__auto__)){
var root_msg = temp__5753__auto__;
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"cause","cause",231901252),root_msg], null);
} else {
return null;
}
})(),(function (){var temp__5753__auto__ = cljs.core.ex_data(root);
if(cljs.core.truth_(temp__5753__auto__)){
var data = temp__5753__auto__;
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"data","data",-232669377),data], null);
} else {
return null;
}
})(),(function (){var temp__5753__auto__ = new cljs.core.Keyword("clojure.error","phase","clojure.error/phase",275140358).cljs$core$IFn$_invoke$arity$1(cljs.core.ex_data(o));
if(cljs.core.truth_(temp__5753__auto__)){
var phase = temp__5753__auto__;
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"phase","phase",575722892),phase], null);
} else {
return null;
}
})()], 0));
});
/**
 * Returns an analysis of the phase, error, cause, and location of an error that occurred
 *   based on Throwable data, as returned by Throwable->map. All attributes other than phase
 *   are optional:
 *  :clojure.error/phase - keyword phase indicator, one of:
 *    :read-source :compile-syntax-check :compilation :macro-syntax-check :macroexpansion
 *    :execution :read-eval-result :print-eval-result
 *  :clojure.error/source - file name (no path)
 *  :clojure.error/line - integer line number
 *  :clojure.error/column - integer column number
 *  :clojure.error/symbol - symbol being expanded/compiled/invoked
 *  :clojure.error/class - cause exception class symbol
 *  :clojure.error/cause - cause exception message
 *  :clojure.error/spec - explain-data for spec error
 */
cljs.repl.ex_triage = (function cljs$repl$ex_triage(datafied_throwable){
var map__35154 = datafied_throwable;
var map__35154__$1 = cljs.core.__destructure_map(map__35154);
var via = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35154__$1,new cljs.core.Keyword(null,"via","via",-1904457336));
var trace = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35154__$1,new cljs.core.Keyword(null,"trace","trace",-1082747415));
var phase = cljs.core.get.cljs$core$IFn$_invoke$arity$3(map__35154__$1,new cljs.core.Keyword(null,"phase","phase",575722892),new cljs.core.Keyword(null,"execution","execution",253283524));
var map__35155 = cljs.core.last(via);
var map__35155__$1 = cljs.core.__destructure_map(map__35155);
var type = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,new cljs.core.Keyword(null,"type","type",1174270348));
var message = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,new cljs.core.Keyword(null,"message","message",-406056002));
var data = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35155__$1,new cljs.core.Keyword(null,"data","data",-232669377));
var map__35156 = data;
var map__35156__$1 = cljs.core.__destructure_map(map__35156);
var problems = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35156__$1,new cljs.core.Keyword("cljs.spec.alpha","problems","cljs.spec.alpha/problems",447400814));
var fn = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35156__$1,new cljs.core.Keyword("cljs.spec.alpha","fn","cljs.spec.alpha/fn",408600443));
var caller = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35156__$1,new cljs.core.Keyword("cljs.spec.test.alpha","caller","cljs.spec.test.alpha/caller",-398302390));
var map__35157 = new cljs.core.Keyword(null,"data","data",-232669377).cljs$core$IFn$_invoke$arity$1(cljs.core.first(via));
var map__35157__$1 = cljs.core.__destructure_map(map__35157);
var top_data = map__35157__$1;
var source = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35157__$1,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397));
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3((function (){var G__35166 = phase;
var G__35166__$1 = (((G__35166 instanceof cljs.core.Keyword))?G__35166.fqn:null);
switch (G__35166__$1) {
case "read-source":
var map__35167 = data;
var map__35167__$1 = cljs.core.__destructure_map(map__35167);
var line = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35167__$1,new cljs.core.Keyword("clojure.error","line","clojure.error/line",-1816287471));
var column = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35167__$1,new cljs.core.Keyword("clojure.error","column","clojure.error/column",304721553));
var G__35169 = cljs.core.merge.cljs$core$IFn$_invoke$arity$variadic(cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"data","data",-232669377).cljs$core$IFn$_invoke$arity$1(cljs.core.second(via)),top_data], 0));
var G__35169__$1 = (cljs.core.truth_(source)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35169,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397),source):G__35169);
var G__35169__$2 = (cljs.core.truth_((function (){var fexpr__35170 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["NO_SOURCE_PATH",null,"NO_SOURCE_FILE",null], null), null);
return (fexpr__35170.cljs$core$IFn$_invoke$arity$1 ? fexpr__35170.cljs$core$IFn$_invoke$arity$1(source) : fexpr__35170.call(null,source));
})())?cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(G__35169__$1,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397)):G__35169__$1);
if(cljs.core.truth_(message)){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35169__$2,new cljs.core.Keyword("clojure.error","cause","clojure.error/cause",-1879175742),message);
} else {
return G__35169__$2;
}

break;
case "compile-syntax-check":
case "compilation":
case "macro-syntax-check":
case "macroexpansion":
var G__35171 = top_data;
var G__35171__$1 = (cljs.core.truth_(source)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35171,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397),source):G__35171);
var G__35171__$2 = (cljs.core.truth_((function (){var fexpr__35172 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["NO_SOURCE_PATH",null,"NO_SOURCE_FILE",null], null), null);
return (fexpr__35172.cljs$core$IFn$_invoke$arity$1 ? fexpr__35172.cljs$core$IFn$_invoke$arity$1(source) : fexpr__35172.call(null,source));
})())?cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(G__35171__$1,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397)):G__35171__$1);
var G__35171__$3 = (cljs.core.truth_(type)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35171__$2,new cljs.core.Keyword("clojure.error","class","clojure.error/class",278435890),type):G__35171__$2);
var G__35171__$4 = (cljs.core.truth_(message)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35171__$3,new cljs.core.Keyword("clojure.error","cause","clojure.error/cause",-1879175742),message):G__35171__$3);
if(cljs.core.truth_(problems)){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35171__$4,new cljs.core.Keyword("clojure.error","spec","clojure.error/spec",2055032595),data);
} else {
return G__35171__$4;
}

break;
case "read-eval-result":
case "print-eval-result":
var vec__35173 = cljs.core.first(trace);
var source__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35173,(0),null);
var method = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35173,(1),null);
var file = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35173,(2),null);
var line = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35173,(3),null);
var G__35183 = top_data;
var G__35183__$1 = (cljs.core.truth_(line)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35183,new cljs.core.Keyword("clojure.error","line","clojure.error/line",-1816287471),line):G__35183);
var G__35183__$2 = (cljs.core.truth_(file)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35183__$1,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397),file):G__35183__$1);
var G__35183__$3 = (cljs.core.truth_((function (){var and__4210__auto__ = source__$1;
if(cljs.core.truth_(and__4210__auto__)){
return method;
} else {
return and__4210__auto__;
}
})())?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35183__$2,new cljs.core.Keyword("clojure.error","symbol","clojure.error/symbol",1544821994),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[source__$1,method],null))):G__35183__$2);
var G__35183__$4 = (cljs.core.truth_(type)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35183__$3,new cljs.core.Keyword("clojure.error","class","clojure.error/class",278435890),type):G__35183__$3);
if(cljs.core.truth_(message)){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35183__$4,new cljs.core.Keyword("clojure.error","cause","clojure.error/cause",-1879175742),message);
} else {
return G__35183__$4;
}

break;
case "execution":
var vec__35188 = cljs.core.first(trace);
var source__$1 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35188,(0),null);
var method = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35188,(1),null);
var file = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35188,(2),null);
var line = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__35188,(3),null);
var file__$1 = cljs.core.first(cljs.core.remove.cljs$core$IFn$_invoke$arity$2((function (p1__35152_SHARP_){
var or__4212__auto__ = (p1__35152_SHARP_ == null);
if(or__4212__auto__){
return or__4212__auto__;
} else {
var fexpr__35191 = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["NO_SOURCE_PATH",null,"NO_SOURCE_FILE",null], null), null);
return (fexpr__35191.cljs$core$IFn$_invoke$arity$1 ? fexpr__35191.cljs$core$IFn$_invoke$arity$1(p1__35152_SHARP_) : fexpr__35191.call(null,p1__35152_SHARP_));
}
}),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(caller),file], null)));
var err_line = (function (){var or__4212__auto__ = new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(caller);
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return line;
}
})();
var G__35192 = new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword("clojure.error","class","clojure.error/class",278435890),type], null);
var G__35192__$1 = (cljs.core.truth_(err_line)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35192,new cljs.core.Keyword("clojure.error","line","clojure.error/line",-1816287471),err_line):G__35192);
var G__35192__$2 = (cljs.core.truth_(message)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35192__$1,new cljs.core.Keyword("clojure.error","cause","clojure.error/cause",-1879175742),message):G__35192__$1);
var G__35192__$3 = (cljs.core.truth_((function (){var or__4212__auto__ = fn;
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
var and__4210__auto__ = source__$1;
if(cljs.core.truth_(and__4210__auto__)){
return method;
} else {
return and__4210__auto__;
}
}
})())?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35192__$2,new cljs.core.Keyword("clojure.error","symbol","clojure.error/symbol",1544821994),(function (){var or__4212__auto__ = fn;
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return (new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[source__$1,method],null));
}
})()):G__35192__$2);
var G__35192__$4 = (cljs.core.truth_(file__$1)?cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35192__$3,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397),file__$1):G__35192__$3);
if(cljs.core.truth_(problems)){
return cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(G__35192__$4,new cljs.core.Keyword("clojure.error","spec","clojure.error/spec",2055032595),data);
} else {
return G__35192__$4;
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__35166__$1)].join('')));

}
})(),new cljs.core.Keyword("clojure.error","phase","clojure.error/phase",275140358),phase);
});
/**
 * Returns a string from exception data, as produced by ex-triage.
 *   The first line summarizes the exception phase and location.
 *   The subsequent lines describe the cause.
 */
cljs.repl.ex_str = (function cljs$repl$ex_str(p__35198){
var map__35199 = p__35198;
var map__35199__$1 = cljs.core.__destructure_map(map__35199);
var triage_data = map__35199__$1;
var phase = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","phase","clojure.error/phase",275140358));
var source = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","source","clojure.error/source",-2011936397));
var line = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","line","clojure.error/line",-1816287471));
var column = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","column","clojure.error/column",304721553));
var symbol = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","symbol","clojure.error/symbol",1544821994));
var class$ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","class","clojure.error/class",278435890));
var cause = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","cause","clojure.error/cause",-1879175742));
var spec = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__35199__$1,new cljs.core.Keyword("clojure.error","spec","clojure.error/spec",2055032595));
var loc = [cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__4212__auto__ = source;
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return "<cljs repl>";
}
})()),":",cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__4212__auto__ = line;
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return (1);
}
})()),(cljs.core.truth_(column)?[":",cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)].join(''):"")].join('');
var class_name = cljs.core.name((function (){var or__4212__auto__ = class$;
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return "";
}
})());
var simple_class = class_name;
var cause_type = ((cljs.core.contains_QMARK_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, ["RuntimeException",null,"Exception",null], null), null),simple_class))?"":[" (",simple_class,")"].join(''));
var format = goog.string.format;
var G__35202 = phase;
var G__35202__$1 = (((G__35202 instanceof cljs.core.Keyword))?G__35202.fqn:null);
switch (G__35202__$1) {
case "read-source":
return (format.cljs$core$IFn$_invoke$arity$3 ? format.cljs$core$IFn$_invoke$arity$3("Syntax error reading source at (%s).\n%s\n",loc,cause) : format.call(null,"Syntax error reading source at (%s).\n%s\n",loc,cause));

break;
case "macro-syntax-check":
var G__35206 = "Syntax error macroexpanding %sat (%s).\n%s";
var G__35207 = (cljs.core.truth_(symbol)?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(symbol)," "].join(''):"");
var G__35208 = loc;
var G__35209 = (cljs.core.truth_(spec)?(function (){var sb__4749__auto__ = (new goog.string.StringBuffer());
var _STAR_print_newline_STAR__orig_val__35213_35380 = cljs.core._STAR_print_newline_STAR_;
var _STAR_print_fn_STAR__orig_val__35214_35381 = cljs.core._STAR_print_fn_STAR_;
var _STAR_print_newline_STAR__temp_val__35215_35382 = true;
var _STAR_print_fn_STAR__temp_val__35216_35383 = (function (x__4750__auto__){
return sb__4749__auto__.append(x__4750__auto__);
});
(cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR__temp_val__35215_35382);

(cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR__temp_val__35216_35383);

try{cljs.spec.alpha.explain_out(cljs.core.update.cljs$core$IFn$_invoke$arity$3(spec,new cljs.core.Keyword("cljs.spec.alpha","problems","cljs.spec.alpha/problems",447400814),(function (probs){
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__35195_SHARP_){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(p1__35195_SHARP_,new cljs.core.Keyword(null,"in","in",-1531184865));
}),probs);
}))
);
}finally {(cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR__orig_val__35214_35381);

(cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR__orig_val__35213_35380);
}
return cljs.core.str.cljs$core$IFn$_invoke$arity$1(sb__4749__auto__);
})():(format.cljs$core$IFn$_invoke$arity$2 ? format.cljs$core$IFn$_invoke$arity$2("%s\n",cause) : format.call(null,"%s\n",cause)));
return (format.cljs$core$IFn$_invoke$arity$4 ? format.cljs$core$IFn$_invoke$arity$4(G__35206,G__35207,G__35208,G__35209) : format.call(null,G__35206,G__35207,G__35208,G__35209));

break;
case "macroexpansion":
var G__35217 = "Unexpected error%s macroexpanding %sat (%s).\n%s\n";
var G__35218 = cause_type;
var G__35219 = (cljs.core.truth_(symbol)?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(symbol)," "].join(''):"");
var G__35220 = loc;
var G__35221 = cause;
return (format.cljs$core$IFn$_invoke$arity$5 ? format.cljs$core$IFn$_invoke$arity$5(G__35217,G__35218,G__35219,G__35220,G__35221) : format.call(null,G__35217,G__35218,G__35219,G__35220,G__35221));

break;
case "compile-syntax-check":
var G__35222 = "Syntax error%s compiling %sat (%s).\n%s\n";
var G__35223 = cause_type;
var G__35224 = (cljs.core.truth_(symbol)?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(symbol)," "].join(''):"");
var G__35225 = loc;
var G__35226 = cause;
return (format.cljs$core$IFn$_invoke$arity$5 ? format.cljs$core$IFn$_invoke$arity$5(G__35222,G__35223,G__35224,G__35225,G__35226) : format.call(null,G__35222,G__35223,G__35224,G__35225,G__35226));

break;
case "compilation":
var G__35227 = "Unexpected error%s compiling %sat (%s).\n%s\n";
var G__35228 = cause_type;
var G__35229 = (cljs.core.truth_(symbol)?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(symbol)," "].join(''):"");
var G__35230 = loc;
var G__35231 = cause;
return (format.cljs$core$IFn$_invoke$arity$5 ? format.cljs$core$IFn$_invoke$arity$5(G__35227,G__35228,G__35229,G__35230,G__35231) : format.call(null,G__35227,G__35228,G__35229,G__35230,G__35231));

break;
case "read-eval-result":
return (format.cljs$core$IFn$_invoke$arity$5 ? format.cljs$core$IFn$_invoke$arity$5("Error reading eval result%s at %s (%s).\n%s\n",cause_type,symbol,loc,cause) : format.call(null,"Error reading eval result%s at %s (%s).\n%s\n",cause_type,symbol,loc,cause));

break;
case "print-eval-result":
return (format.cljs$core$IFn$_invoke$arity$5 ? format.cljs$core$IFn$_invoke$arity$5("Error printing return value%s at %s (%s).\n%s\n",cause_type,symbol,loc,cause) : format.call(null,"Error printing return value%s at %s (%s).\n%s\n",cause_type,symbol,loc,cause));

break;
case "execution":
if(cljs.core.truth_(spec)){
var G__35232 = "Execution error - invalid arguments to %s at (%s).\n%s";
var G__35233 = symbol;
var G__35234 = loc;
var G__35235 = (function (){var sb__4749__auto__ = (new goog.string.StringBuffer());
var _STAR_print_newline_STAR__orig_val__35236_35386 = cljs.core._STAR_print_newline_STAR_;
var _STAR_print_fn_STAR__orig_val__35237_35387 = cljs.core._STAR_print_fn_STAR_;
var _STAR_print_newline_STAR__temp_val__35238_35388 = true;
var _STAR_print_fn_STAR__temp_val__35239_35389 = (function (x__4750__auto__){
return sb__4749__auto__.append(x__4750__auto__);
});
(cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR__temp_val__35238_35388);

(cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR__temp_val__35239_35389);

try{cljs.spec.alpha.explain_out(cljs.core.update.cljs$core$IFn$_invoke$arity$3(spec,new cljs.core.Keyword("cljs.spec.alpha","problems","cljs.spec.alpha/problems",447400814),(function (probs){
return cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p1__35196_SHARP_){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(p1__35196_SHARP_,new cljs.core.Keyword(null,"in","in",-1531184865));
}),probs);
}))
);
}finally {(cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR__orig_val__35237_35387);

(cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR__orig_val__35236_35386);
}
return cljs.core.str.cljs$core$IFn$_invoke$arity$1(sb__4749__auto__);
})();
return (format.cljs$core$IFn$_invoke$arity$4 ? format.cljs$core$IFn$_invoke$arity$4(G__35232,G__35233,G__35234,G__35235) : format.call(null,G__35232,G__35233,G__35234,G__35235));
} else {
var G__35241 = "Execution error%s at %s(%s).\n%s\n";
var G__35242 = cause_type;
var G__35243 = (cljs.core.truth_(symbol)?[cljs.core.str.cljs$core$IFn$_invoke$arity$1(symbol)," "].join(''):"");
var G__35244 = loc;
var G__35245 = cause;
return (format.cljs$core$IFn$_invoke$arity$5 ? format.cljs$core$IFn$_invoke$arity$5(G__35241,G__35242,G__35243,G__35244,G__35245) : format.call(null,G__35241,G__35242,G__35243,G__35244,G__35245));
}

break;
default:
throw (new Error(["No matching clause: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__35202__$1)].join('')));

}
});
cljs.repl.error__GT_str = (function cljs$repl$error__GT_str(error){
return cljs.repl.ex_str(cljs.repl.ex_triage(cljs.repl.Error__GT_map(error)));
});

//# sourceMappingURL=cljs.repl.js.map
