goog.provide("goog.dom.HtmlElement");
goog.dom.HtmlElement = function() {
};

//# sourceMappingURL=goog.dom.htmlelement.js.map
