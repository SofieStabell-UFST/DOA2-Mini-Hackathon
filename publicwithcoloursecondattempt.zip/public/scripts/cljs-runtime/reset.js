goog.provide('reset');
reset.clear_simulator = (function reset$clear_simulator(){
simulation.pause();

cljs.core.reset_BANG_(simulation.sim_time,(0));

cljs.core.reset_BANG_(simulation.interval,null);

clearInterval(cljs.core.deref(simulation.interval));

cljs.core.reset_BANG_(simulation.total_process_time,(0));

cljs.core.reset_BANG_(simulation.total_lead_time,(0));

cljs.core.reset_BANG_(simulation.skovhygge_input,(0));

cljs.core.reset_BANG_(simulation.skov_output,(0));

cljs.core.reset_BANG_(processtime.process_time_skovhugger_original,(1));

var seq__26977_27014 = cljs.core.seq(cljs.core.range.cljs$core$IFn$_invoke$arity$1((5)));
var chunk__26978_27015 = null;
var count__26979_27016 = (0);
var i__26980_27017 = (0);
while(true){
if((i__26980_27017 < count__26979_27016)){
var i_27018 = chunk__26978_27015.cljs$core$IIndexed$_nth$arity$2(null,i__26980_27017);
cljs.core.reset_BANG_((simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(i_27018) : simulation.queues.call(null,i_27018)),cljs.core.PersistentVector.EMPTY);


var G__27019 = seq__26977_27014;
var G__27020 = chunk__26978_27015;
var G__27021 = count__26979_27016;
var G__27022 = (i__26980_27017 + (1));
seq__26977_27014 = G__27019;
chunk__26978_27015 = G__27020;
count__26979_27016 = G__27021;
i__26980_27017 = G__27022;
continue;
} else {
var temp__5753__auto___27023 = cljs.core.seq(seq__26977_27014);
if(temp__5753__auto___27023){
var seq__26977_27024__$1 = temp__5753__auto___27023;
if(cljs.core.chunked_seq_QMARK_(seq__26977_27024__$1)){
var c__4638__auto___27025 = cljs.core.chunk_first(seq__26977_27024__$1);
var G__27026 = cljs.core.chunk_rest(seq__26977_27024__$1);
var G__27027 = c__4638__auto___27025;
var G__27028 = cljs.core.count(c__4638__auto___27025);
var G__27029 = (0);
seq__26977_27014 = G__27026;
chunk__26978_27015 = G__27027;
count__26979_27016 = G__27028;
i__26980_27017 = G__27029;
continue;
} else {
var i_27030 = cljs.core.first(seq__26977_27024__$1);
cljs.core.reset_BANG_((simulation.queues.cljs$core$IFn$_invoke$arity$1 ? simulation.queues.cljs$core$IFn$_invoke$arity$1(i_27030) : simulation.queues.call(null,i_27030)),cljs.core.PersistentVector.EMPTY);


var G__27031 = cljs.core.next(seq__26977_27024__$1);
var G__27032 = null;
var G__27033 = (0);
var G__27034 = (0);
seq__26977_27014 = G__27031;
chunk__26978_27015 = G__27032;
count__26979_27016 = G__27033;
i__26980_27017 = G__27034;
continue;
}
} else {
}
}
break;
}

cljs.core.reset_BANG_(simulation.item_1,(0));

cljs.core.reset_BANG_(simulation.item_2,(0));

cljs.core.reset_BANG_(simulation.item_3,(0));

cljs.core.reset_BANG_(simulation.item_4,(0));

cljs.core.reset_BANG_(simulation.item_5,(0));

cljs.core.reset_BANG_(simulation.lead_time_1,"-");

cljs.core.reset_BANG_(simulation.lead_time_2,"-");

cljs.core.reset_BANG_(simulation.lead_time_3,"-");

cljs.core.reset_BANG_(simulation.lead_time_4,"-");

return cljs.core.reset_BANG_(simulation.lead_time_5,"-");
});
reset.reset_btn = (function reset$reset_btn(){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"input.button.reset-button","input.button.reset-button",2062342889),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"type","type",1174270348),"button",new cljs.core.Keyword(null,"value","value",305978217),"Ryd",new cljs.core.Keyword(null,"on-click","on-click",1632826543),(function (){
return reset.clear_simulator();
})], null)], null);
});

//# sourceMappingURL=reset.js.map
