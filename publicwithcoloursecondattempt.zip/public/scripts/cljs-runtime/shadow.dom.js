goog.provide('shadow.dom');
shadow.dom.transition_supported_QMARK_ = (((typeof window !== 'undefined'))?goog.style.transition.isSupported():null);

/**
 * @interface
 */
shadow.dom.IElement = function(){};

var shadow$dom$IElement$_to_dom$dyn_33845 = (function (this$){
var x__4509__auto__ = (((this$ == null))?null:this$);
var m__4510__auto__ = (shadow.dom._to_dom[goog.typeOf(x__4509__auto__)]);
if((!((m__4510__auto__ == null)))){
return (m__4510__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4510__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4510__auto__.call(null,this$));
} else {
var m__4508__auto__ = (shadow.dom._to_dom["_"]);
if((!((m__4508__auto__ == null)))){
return (m__4508__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4508__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4508__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("IElement.-to-dom",this$);
}
}
});
shadow.dom._to_dom = (function shadow$dom$_to_dom(this$){
if((((!((this$ == null)))) && ((!((this$.shadow$dom$IElement$_to_dom$arity$1 == null)))))){
return this$.shadow$dom$IElement$_to_dom$arity$1(this$);
} else {
return shadow$dom$IElement$_to_dom$dyn_33845(this$);
}
});


/**
 * @interface
 */
shadow.dom.SVGElement = function(){};

var shadow$dom$SVGElement$_to_svg$dyn_33846 = (function (this$){
var x__4509__auto__ = (((this$ == null))?null:this$);
var m__4510__auto__ = (shadow.dom._to_svg[goog.typeOf(x__4509__auto__)]);
if((!((m__4510__auto__ == null)))){
return (m__4510__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4510__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4510__auto__.call(null,this$));
} else {
var m__4508__auto__ = (shadow.dom._to_svg["_"]);
if((!((m__4508__auto__ == null)))){
return (m__4508__auto__.cljs$core$IFn$_invoke$arity$1 ? m__4508__auto__.cljs$core$IFn$_invoke$arity$1(this$) : m__4508__auto__.call(null,this$));
} else {
throw cljs.core.missing_protocol("SVGElement.-to-svg",this$);
}
}
});
shadow.dom._to_svg = (function shadow$dom$_to_svg(this$){
if((((!((this$ == null)))) && ((!((this$.shadow$dom$SVGElement$_to_svg$arity$1 == null)))))){
return this$.shadow$dom$SVGElement$_to_svg$arity$1(this$);
} else {
return shadow$dom$SVGElement$_to_svg$dyn_33846(this$);
}
});

shadow.dom.lazy_native_coll_seq = (function shadow$dom$lazy_native_coll_seq(coll,idx){
if((idx < coll.length)){
return (new cljs.core.LazySeq(null,(function (){
return cljs.core.cons((coll[idx]),(function (){var G__32713 = coll;
var G__32714 = (idx + (1));
return (shadow.dom.lazy_native_coll_seq.cljs$core$IFn$_invoke$arity$2 ? shadow.dom.lazy_native_coll_seq.cljs$core$IFn$_invoke$arity$2(G__32713,G__32714) : shadow.dom.lazy_native_coll_seq.call(null,G__32713,G__32714));
})());
}),null,null));
} else {
return null;
}
});

/**
* @constructor
 * @implements {cljs.core.IIndexed}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IDeref}
 * @implements {shadow.dom.IElement}
*/
shadow.dom.NativeColl = (function (coll){
this.coll = coll;
this.cljs$lang$protocol_mask$partition0$ = 8421394;
this.cljs$lang$protocol_mask$partition1$ = 0;
});
(shadow.dom.NativeColl.prototype.cljs$core$IDeref$_deref$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.coll;
}));

(shadow.dom.NativeColl.prototype.cljs$core$IIndexed$_nth$arity$2 = (function (this$,n){
var self__ = this;
var this$__$1 = this;
return (self__.coll[n]);
}));

(shadow.dom.NativeColl.prototype.cljs$core$IIndexed$_nth$arity$3 = (function (this$,n,not_found){
var self__ = this;
var this$__$1 = this;
var or__4212__auto__ = (self__.coll[n]);
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return not_found;
}
}));

(shadow.dom.NativeColl.prototype.cljs$core$ICounted$_count$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.coll.length;
}));

(shadow.dom.NativeColl.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return shadow.dom.lazy_native_coll_seq(self__.coll,(0));
}));

(shadow.dom.NativeColl.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL);

(shadow.dom.NativeColl.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var self__ = this;
var this$__$1 = this;
return self__.coll;
}));

(shadow.dom.NativeColl.getBasis = (function (){
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"coll","coll",-1006698606,null)], null);
}));

(shadow.dom.NativeColl.cljs$lang$type = true);

(shadow.dom.NativeColl.cljs$lang$ctorStr = "shadow.dom/NativeColl");

(shadow.dom.NativeColl.cljs$lang$ctorPrWriter = (function (this__4450__auto__,writer__4451__auto__,opt__4452__auto__){
return cljs.core._write(writer__4451__auto__,"shadow.dom/NativeColl");
}));

/**
 * Positional factory function for shadow.dom/NativeColl.
 */
shadow.dom.__GT_NativeColl = (function shadow$dom$__GT_NativeColl(coll){
return (new shadow.dom.NativeColl(coll));
});

shadow.dom.native_coll = (function shadow$dom$native_coll(coll){
return (new shadow.dom.NativeColl(coll));
});
shadow.dom.dom_node = (function shadow$dom$dom_node(el){
if((el == null)){
return null;
} else {
if((((!((el == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === el.shadow$dom$IElement$))))?true:false):false)){
return el.shadow$dom$IElement$_to_dom$arity$1(null);
} else {
if(typeof el === 'string'){
return document.createTextNode(el);
} else {
if(typeof el === 'number'){
return document.createTextNode(cljs.core.str.cljs$core$IFn$_invoke$arity$1(el));
} else {
return el;

}
}
}
}
});
shadow.dom.query_one = (function shadow$dom$query_one(var_args){
var G__32779 = arguments.length;
switch (G__32779) {
case 1:
return shadow.dom.query_one.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.query_one.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.query_one.cljs$core$IFn$_invoke$arity$1 = (function (sel){
return document.querySelector(sel);
}));

(shadow.dom.query_one.cljs$core$IFn$_invoke$arity$2 = (function (sel,root){
return shadow.dom.dom_node(root).querySelector(sel);
}));

(shadow.dom.query_one.cljs$lang$maxFixedArity = 2);

shadow.dom.query = (function shadow$dom$query(var_args){
var G__32796 = arguments.length;
switch (G__32796) {
case 1:
return shadow.dom.query.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.query.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.query.cljs$core$IFn$_invoke$arity$1 = (function (sel){
return (new shadow.dom.NativeColl(document.querySelectorAll(sel)));
}));

(shadow.dom.query.cljs$core$IFn$_invoke$arity$2 = (function (sel,root){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(root).querySelectorAll(sel)));
}));

(shadow.dom.query.cljs$lang$maxFixedArity = 2);

shadow.dom.by_id = (function shadow$dom$by_id(var_args){
var G__32815 = arguments.length;
switch (G__32815) {
case 2:
return shadow.dom.by_id.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return shadow.dom.by_id.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.by_id.cljs$core$IFn$_invoke$arity$2 = (function (id,el){
return shadow.dom.dom_node(el).getElementById(id);
}));

(shadow.dom.by_id.cljs$core$IFn$_invoke$arity$1 = (function (id){
return document.getElementById(id);
}));

(shadow.dom.by_id.cljs$lang$maxFixedArity = 2);

shadow.dom.build = shadow.dom.dom_node;
shadow.dom.ev_stop = (function shadow$dom$ev_stop(var_args){
var G__32828 = arguments.length;
switch (G__32828) {
case 1:
return shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1 = (function (e){
if(cljs.core.truth_(e.stopPropagation)){
e.stopPropagation();

e.preventDefault();
} else {
(e.cancelBubble = true);

(e.returnValue = false);
}

return e;
}));

(shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$2 = (function (e,el){
shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1(e);

return el;
}));

(shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$4 = (function (e,el,scope,owner){
shadow.dom.ev_stop.cljs$core$IFn$_invoke$arity$1(e);

return el;
}));

(shadow.dom.ev_stop.cljs$lang$maxFixedArity = 4);

/**
 * check wether a parent node (or the document) contains the child
 */
shadow.dom.contains_QMARK_ = (function shadow$dom$contains_QMARK_(var_args){
var G__32837 = arguments.length;
switch (G__32837) {
case 1:
return shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$1 = (function (el){
return goog.dom.contains(document,shadow.dom.dom_node(el));
}));

(shadow.dom.contains_QMARK_.cljs$core$IFn$_invoke$arity$2 = (function (parent,el){
return goog.dom.contains(shadow.dom.dom_node(parent),shadow.dom.dom_node(el));
}));

(shadow.dom.contains_QMARK_.cljs$lang$maxFixedArity = 2);

shadow.dom.add_class = (function shadow$dom$add_class(el,cls){
return goog.dom.classlist.add(shadow.dom.dom_node(el),cls);
});
shadow.dom.remove_class = (function shadow$dom$remove_class(el,cls){
return goog.dom.classlist.remove(shadow.dom.dom_node(el),cls);
});
shadow.dom.toggle_class = (function shadow$dom$toggle_class(var_args){
var G__32850 = arguments.length;
switch (G__32850) {
case 2:
return shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$2 = (function (el,cls){
return goog.dom.classlist.toggle(shadow.dom.dom_node(el),cls);
}));

(shadow.dom.toggle_class.cljs$core$IFn$_invoke$arity$3 = (function (el,cls,v){
if(cljs.core.truth_(v)){
return shadow.dom.add_class(el,cls);
} else {
return shadow.dom.remove_class(el,cls);
}
}));

(shadow.dom.toggle_class.cljs$lang$maxFixedArity = 3);

shadow.dom.dom_listen = (cljs.core.truth_((function (){var or__4212__auto__ = (!((typeof document !== 'undefined')));
if(or__4212__auto__){
return or__4212__auto__;
} else {
return document.addEventListener;
}
})())?(function shadow$dom$dom_listen_good(el,ev,handler){
return el.addEventListener(ev,handler,false);
}):(function shadow$dom$dom_listen_ie(el,ev,handler){
try{return el.attachEvent(["on",cljs.core.str.cljs$core$IFn$_invoke$arity$1(ev)].join(''),(function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
}));
}catch (e32858){if((e32858 instanceof Object)){
var e = e32858;
return console.log("didnt support attachEvent",el,e);
} else {
throw e32858;

}
}}));
shadow.dom.dom_listen_remove = (cljs.core.truth_((function (){var or__4212__auto__ = (!((typeof document !== 'undefined')));
if(or__4212__auto__){
return or__4212__auto__;
} else {
return document.removeEventListener;
}
})())?(function shadow$dom$dom_listen_remove_good(el,ev,handler){
return el.removeEventListener(ev,handler,false);
}):(function shadow$dom$dom_listen_remove_ie(el,ev,handler){
return el.detachEvent(["on",cljs.core.str.cljs$core$IFn$_invoke$arity$1(ev)].join(''),handler);
}));
shadow.dom.on_query = (function shadow$dom$on_query(root_el,ev,selector,handler){
var seq__32868 = cljs.core.seq(shadow.dom.query.cljs$core$IFn$_invoke$arity$2(selector,root_el));
var chunk__32869 = null;
var count__32870 = (0);
var i__32871 = (0);
while(true){
if((i__32871 < count__32870)){
var el = chunk__32869.cljs$core$IIndexed$_nth$arity$2(null,i__32871);
var handler_33857__$1 = ((function (seq__32868,chunk__32869,count__32870,i__32871,el){
return (function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
});})(seq__32868,chunk__32869,count__32870,i__32871,el))
;
shadow.dom.dom_listen(el,cljs.core.name(ev),handler_33857__$1);


var G__33858 = seq__32868;
var G__33859 = chunk__32869;
var G__33860 = count__32870;
var G__33861 = (i__32871 + (1));
seq__32868 = G__33858;
chunk__32869 = G__33859;
count__32870 = G__33860;
i__32871 = G__33861;
continue;
} else {
var temp__5753__auto__ = cljs.core.seq(seq__32868);
if(temp__5753__auto__){
var seq__32868__$1 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__32868__$1)){
var c__4638__auto__ = cljs.core.chunk_first(seq__32868__$1);
var G__33862 = cljs.core.chunk_rest(seq__32868__$1);
var G__33863 = c__4638__auto__;
var G__33864 = cljs.core.count(c__4638__auto__);
var G__33865 = (0);
seq__32868 = G__33862;
chunk__32869 = G__33863;
count__32870 = G__33864;
i__32871 = G__33865;
continue;
} else {
var el = cljs.core.first(seq__32868__$1);
var handler_33866__$1 = ((function (seq__32868,chunk__32869,count__32870,i__32871,el,seq__32868__$1,temp__5753__auto__){
return (function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
});})(seq__32868,chunk__32869,count__32870,i__32871,el,seq__32868__$1,temp__5753__auto__))
;
shadow.dom.dom_listen(el,cljs.core.name(ev),handler_33866__$1);


var G__33867 = cljs.core.next(seq__32868__$1);
var G__33868 = null;
var G__33869 = (0);
var G__33870 = (0);
seq__32868 = G__33867;
chunk__32869 = G__33868;
count__32870 = G__33869;
i__32871 = G__33870;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.dom.on = (function shadow$dom$on(var_args){
var G__32889 = arguments.length;
switch (G__32889) {
case 3:
return shadow.dom.on.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return shadow.dom.on.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.on.cljs$core$IFn$_invoke$arity$3 = (function (el,ev,handler){
return shadow.dom.on.cljs$core$IFn$_invoke$arity$4(el,ev,handler,false);
}));

(shadow.dom.on.cljs$core$IFn$_invoke$arity$4 = (function (el,ev,handler,capture){
if(cljs.core.vector_QMARK_(ev)){
return shadow.dom.on_query(el,cljs.core.first(ev),cljs.core.second(ev),handler);
} else {
var handler__$1 = (function (e){
return (handler.cljs$core$IFn$_invoke$arity$2 ? handler.cljs$core$IFn$_invoke$arity$2(e,el) : handler.call(null,e,el));
});
return shadow.dom.dom_listen(shadow.dom.dom_node(el),cljs.core.name(ev),handler__$1);
}
}));

(shadow.dom.on.cljs$lang$maxFixedArity = 4);

shadow.dom.remove_event_handler = (function shadow$dom$remove_event_handler(el,ev,handler){
return shadow.dom.dom_listen_remove(shadow.dom.dom_node(el),cljs.core.name(ev),handler);
});
shadow.dom.add_event_listeners = (function shadow$dom$add_event_listeners(el,events){
var seq__32904 = cljs.core.seq(events);
var chunk__32905 = null;
var count__32906 = (0);
var i__32907 = (0);
while(true){
if((i__32907 < count__32906)){
var vec__32918 = chunk__32905.cljs$core$IIndexed$_nth$arity$2(null,i__32907);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32918,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32918,(1),null);
shadow.dom.on.cljs$core$IFn$_invoke$arity$3(el,k,v);


var G__33872 = seq__32904;
var G__33873 = chunk__32905;
var G__33874 = count__32906;
var G__33875 = (i__32907 + (1));
seq__32904 = G__33872;
chunk__32905 = G__33873;
count__32906 = G__33874;
i__32907 = G__33875;
continue;
} else {
var temp__5753__auto__ = cljs.core.seq(seq__32904);
if(temp__5753__auto__){
var seq__32904__$1 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__32904__$1)){
var c__4638__auto__ = cljs.core.chunk_first(seq__32904__$1);
var G__33876 = cljs.core.chunk_rest(seq__32904__$1);
var G__33877 = c__4638__auto__;
var G__33878 = cljs.core.count(c__4638__auto__);
var G__33879 = (0);
seq__32904 = G__33876;
chunk__32905 = G__33877;
count__32906 = G__33878;
i__32907 = G__33879;
continue;
} else {
var vec__32923 = cljs.core.first(seq__32904__$1);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32923,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32923,(1),null);
shadow.dom.on.cljs$core$IFn$_invoke$arity$3(el,k,v);


var G__33880 = cljs.core.next(seq__32904__$1);
var G__33881 = null;
var G__33882 = (0);
var G__33883 = (0);
seq__32904 = G__33880;
chunk__32905 = G__33881;
count__32906 = G__33882;
i__32907 = G__33883;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.dom.set_style = (function shadow$dom$set_style(el,styles){
var dom = shadow.dom.dom_node(el);
var seq__32929 = cljs.core.seq(styles);
var chunk__32930 = null;
var count__32931 = (0);
var i__32932 = (0);
while(true){
if((i__32932 < count__32931)){
var vec__32941 = chunk__32930.cljs$core$IIndexed$_nth$arity$2(null,i__32932);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32941,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32941,(1),null);
goog.style.setStyle(dom,cljs.core.name(k),(((v == null))?"":v));


var G__33884 = seq__32929;
var G__33885 = chunk__32930;
var G__33886 = count__32931;
var G__33887 = (i__32932 + (1));
seq__32929 = G__33884;
chunk__32930 = G__33885;
count__32931 = G__33886;
i__32932 = G__33887;
continue;
} else {
var temp__5753__auto__ = cljs.core.seq(seq__32929);
if(temp__5753__auto__){
var seq__32929__$1 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__32929__$1)){
var c__4638__auto__ = cljs.core.chunk_first(seq__32929__$1);
var G__33888 = cljs.core.chunk_rest(seq__32929__$1);
var G__33889 = c__4638__auto__;
var G__33890 = cljs.core.count(c__4638__auto__);
var G__33891 = (0);
seq__32929 = G__33888;
chunk__32930 = G__33889;
count__32931 = G__33890;
i__32932 = G__33891;
continue;
} else {
var vec__32949 = cljs.core.first(seq__32929__$1);
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32949,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__32949,(1),null);
goog.style.setStyle(dom,cljs.core.name(k),(((v == null))?"":v));


var G__33892 = cljs.core.next(seq__32929__$1);
var G__33893 = null;
var G__33894 = (0);
var G__33895 = (0);
seq__32929 = G__33892;
chunk__32930 = G__33893;
count__32931 = G__33894;
i__32932 = G__33895;
continue;
}
} else {
return null;
}
}
break;
}
});
shadow.dom.set_attr_STAR_ = (function shadow$dom$set_attr_STAR_(el,key,value){
var G__32961_33896 = key;
var G__32961_33897__$1 = (((G__32961_33896 instanceof cljs.core.Keyword))?G__32961_33896.fqn:null);
switch (G__32961_33897__$1) {
case "id":
(el.id = cljs.core.str.cljs$core$IFn$_invoke$arity$1(value));

break;
case "class":
(el.className = cljs.core.str.cljs$core$IFn$_invoke$arity$1(value));

break;
case "for":
(el.htmlFor = value);

break;
case "cellpadding":
el.setAttribute("cellPadding",value);

break;
case "cellspacing":
el.setAttribute("cellSpacing",value);

break;
case "colspan":
el.setAttribute("colSpan",value);

break;
case "frameborder":
el.setAttribute("frameBorder",value);

break;
case "height":
el.setAttribute("height",value);

break;
case "maxlength":
el.setAttribute("maxLength",value);

break;
case "role":
el.setAttribute("role",value);

break;
case "rowspan":
el.setAttribute("rowSpan",value);

break;
case "type":
el.setAttribute("type",value);

break;
case "usemap":
el.setAttribute("useMap",value);

break;
case "valign":
el.setAttribute("vAlign",value);

break;
case "width":
el.setAttribute("width",value);

break;
case "on":
shadow.dom.add_event_listeners(el,value);

break;
case "style":
if((value == null)){
} else {
if(typeof value === 'string'){
el.setAttribute("style",value);
} else {
if(cljs.core.map_QMARK_(value)){
shadow.dom.set_style(el,value);
} else {
goog.style.setStyle(el,value);

}
}
}

break;
default:
var ks_33901 = cljs.core.name(key);
if(cljs.core.truth_((function (){var or__4212__auto__ = goog.string.startsWith(ks_33901,"data-");
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return goog.string.startsWith(ks_33901,"aria-");
}
})())){
el.setAttribute(ks_33901,value);
} else {
(el[ks_33901] = value);
}

}

return el;
});
shadow.dom.set_attrs = (function shadow$dom$set_attrs(el,attrs){
return cljs.core.reduce_kv((function (el__$1,key,value){
shadow.dom.set_attr_STAR_(el__$1,key,value);

return el__$1;
}),shadow.dom.dom_node(el),attrs);
});
shadow.dom.set_attr = (function shadow$dom$set_attr(el,key,value){
return shadow.dom.set_attr_STAR_(shadow.dom.dom_node(el),key,value);
});
shadow.dom.has_class_QMARK_ = (function shadow$dom$has_class_QMARK_(el,cls){
return goog.dom.classlist.contains(shadow.dom.dom_node(el),cls);
});
shadow.dom.merge_class_string = (function shadow$dom$merge_class_string(current,extra_class){
if(cljs.core.seq(current)){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(current)," ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(extra_class)].join('');
} else {
return extra_class;
}
});
shadow.dom.parse_tag = (function shadow$dom$parse_tag(spec){
var spec__$1 = cljs.core.name(spec);
var fdot = spec__$1.indexOf(".");
var fhash = spec__$1.indexOf("#");
if(((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fdot)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fhash)))){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1,null,null], null);
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fhash)){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1.substring((0),fdot),null,clojure.string.replace(spec__$1.substring((fdot + (1))),/\./," ")], null);
} else {
if(cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2((-1),fdot)){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1.substring((0),fhash),spec__$1.substring((fhash + (1))),null], null);
} else {
if((fhash > fdot)){
throw ["cant have id after class?",spec__$1].join('');
} else {
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [spec__$1.substring((0),fhash),spec__$1.substring((fhash + (1)),fdot),clojure.string.replace(spec__$1.substring((fdot + (1))),/\./," ")], null);

}
}
}
}
});
shadow.dom.create_dom_node = (function shadow$dom$create_dom_node(tag_def,p__33026){
var map__33028 = p__33026;
var map__33028__$1 = cljs.core.__destructure_map(map__33028);
var props = map__33028__$1;
var class$ = cljs.core.get.cljs$core$IFn$_invoke$arity$2(map__33028__$1,new cljs.core.Keyword(null,"class","class",-2030961996));
var tag_props = ({});
var vec__33032 = shadow.dom.parse_tag(tag_def);
var tag_name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33032,(0),null);
var tag_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33032,(1),null);
var tag_classes = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33032,(2),null);
if(cljs.core.truth_(tag_id)){
(tag_props["id"] = tag_id);
} else {
}

if(cljs.core.truth_(tag_classes)){
(tag_props["class"] = shadow.dom.merge_class_string(class$,tag_classes));
} else {
}

var G__33042 = goog.dom.createDom(tag_name,tag_props);
shadow.dom.set_attrs(G__33042,cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(props,new cljs.core.Keyword(null,"class","class",-2030961996)));

return G__33042;
});
shadow.dom.append = (function shadow$dom$append(var_args){
var G__33053 = arguments.length;
switch (G__33053) {
case 1:
return shadow.dom.append.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.append.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.append.cljs$core$IFn$_invoke$arity$1 = (function (node){
if(cljs.core.truth_(node)){
var temp__5753__auto__ = shadow.dom.dom_node(node);
if(cljs.core.truth_(temp__5753__auto__)){
var n = temp__5753__auto__;
document.body.appendChild(n);

return n;
} else {
return null;
}
} else {
return null;
}
}));

(shadow.dom.append.cljs$core$IFn$_invoke$arity$2 = (function (el,node){
if(cljs.core.truth_(node)){
var temp__5753__auto__ = shadow.dom.dom_node(node);
if(cljs.core.truth_(temp__5753__auto__)){
var n = temp__5753__auto__;
shadow.dom.dom_node(el).appendChild(n);

return n;
} else {
return null;
}
} else {
return null;
}
}));

(shadow.dom.append.cljs$lang$maxFixedArity = 2);

shadow.dom.destructure_node = (function shadow$dom$destructure_node(create_fn,p__33071){
var vec__33075 = p__33071;
var seq__33076 = cljs.core.seq(vec__33075);
var first__33077 = cljs.core.first(seq__33076);
var seq__33076__$1 = cljs.core.next(seq__33076);
var nn = first__33077;
var first__33077__$1 = cljs.core.first(seq__33076__$1);
var seq__33076__$2 = cljs.core.next(seq__33076__$1);
var np = first__33077__$1;
var nc = seq__33076__$2;
var node = vec__33075;
if((nn instanceof cljs.core.Keyword)){
} else {
throw cljs.core.ex_info.cljs$core$IFn$_invoke$arity$2("invalid dom node",new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"node","node",581201198),node], null));
}

if((((np == null)) && ((nc == null)))){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var G__33086 = nn;
var G__33087 = cljs.core.PersistentArrayMap.EMPTY;
return (create_fn.cljs$core$IFn$_invoke$arity$2 ? create_fn.cljs$core$IFn$_invoke$arity$2(G__33086,G__33087) : create_fn.call(null,G__33086,G__33087));
})(),cljs.core.List.EMPTY], null);
} else {
if(cljs.core.map_QMARK_(np)){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(create_fn.cljs$core$IFn$_invoke$arity$2 ? create_fn.cljs$core$IFn$_invoke$arity$2(nn,np) : create_fn.call(null,nn,np)),nc], null);
} else {
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(function (){var G__33090 = nn;
var G__33091 = cljs.core.PersistentArrayMap.EMPTY;
return (create_fn.cljs$core$IFn$_invoke$arity$2 ? create_fn.cljs$core$IFn$_invoke$arity$2(G__33090,G__33091) : create_fn.call(null,G__33090,G__33091));
})(),cljs.core.conj.cljs$core$IFn$_invoke$arity$2(nc,np)], null);

}
}
});
shadow.dom.make_dom_node = (function shadow$dom$make_dom_node(structure){
var vec__33098 = shadow.dom.destructure_node(shadow.dom.create_dom_node,structure);
var node = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33098,(0),null);
var node_children = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33098,(1),null);
var seq__33102_33908 = cljs.core.seq(node_children);
var chunk__33103_33909 = null;
var count__33104_33910 = (0);
var i__33105_33911 = (0);
while(true){
if((i__33105_33911 < count__33104_33910)){
var child_struct_33912 = chunk__33103_33909.cljs$core$IIndexed$_nth$arity$2(null,i__33105_33911);
var children_33913 = shadow.dom.dom_node(child_struct_33912);
if(cljs.core.seq_QMARK_(children_33913)){
var seq__33178_33914 = cljs.core.seq(cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom.dom_node,children_33913));
var chunk__33180_33915 = null;
var count__33181_33916 = (0);
var i__33182_33917 = (0);
while(true){
if((i__33182_33917 < count__33181_33916)){
var child_33918 = chunk__33180_33915.cljs$core$IIndexed$_nth$arity$2(null,i__33182_33917);
if(cljs.core.truth_(child_33918)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_33918);


var G__33919 = seq__33178_33914;
var G__33920 = chunk__33180_33915;
var G__33921 = count__33181_33916;
var G__33922 = (i__33182_33917 + (1));
seq__33178_33914 = G__33919;
chunk__33180_33915 = G__33920;
count__33181_33916 = G__33921;
i__33182_33917 = G__33922;
continue;
} else {
var G__33923 = seq__33178_33914;
var G__33924 = chunk__33180_33915;
var G__33925 = count__33181_33916;
var G__33926 = (i__33182_33917 + (1));
seq__33178_33914 = G__33923;
chunk__33180_33915 = G__33924;
count__33181_33916 = G__33925;
i__33182_33917 = G__33926;
continue;
}
} else {
var temp__5753__auto___33927 = cljs.core.seq(seq__33178_33914);
if(temp__5753__auto___33927){
var seq__33178_33928__$1 = temp__5753__auto___33927;
if(cljs.core.chunked_seq_QMARK_(seq__33178_33928__$1)){
var c__4638__auto___33929 = cljs.core.chunk_first(seq__33178_33928__$1);
var G__33930 = cljs.core.chunk_rest(seq__33178_33928__$1);
var G__33931 = c__4638__auto___33929;
var G__33932 = cljs.core.count(c__4638__auto___33929);
var G__33933 = (0);
seq__33178_33914 = G__33930;
chunk__33180_33915 = G__33931;
count__33181_33916 = G__33932;
i__33182_33917 = G__33933;
continue;
} else {
var child_33934 = cljs.core.first(seq__33178_33928__$1);
if(cljs.core.truth_(child_33934)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_33934);


var G__33935 = cljs.core.next(seq__33178_33928__$1);
var G__33936 = null;
var G__33937 = (0);
var G__33938 = (0);
seq__33178_33914 = G__33935;
chunk__33180_33915 = G__33936;
count__33181_33916 = G__33937;
i__33182_33917 = G__33938;
continue;
} else {
var G__33939 = cljs.core.next(seq__33178_33928__$1);
var G__33940 = null;
var G__33941 = (0);
var G__33942 = (0);
seq__33178_33914 = G__33939;
chunk__33180_33915 = G__33940;
count__33181_33916 = G__33941;
i__33182_33917 = G__33942;
continue;
}
}
} else {
}
}
break;
}
} else {
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,children_33913);
}


var G__33943 = seq__33102_33908;
var G__33944 = chunk__33103_33909;
var G__33945 = count__33104_33910;
var G__33946 = (i__33105_33911 + (1));
seq__33102_33908 = G__33943;
chunk__33103_33909 = G__33944;
count__33104_33910 = G__33945;
i__33105_33911 = G__33946;
continue;
} else {
var temp__5753__auto___33947 = cljs.core.seq(seq__33102_33908);
if(temp__5753__auto___33947){
var seq__33102_33948__$1 = temp__5753__auto___33947;
if(cljs.core.chunked_seq_QMARK_(seq__33102_33948__$1)){
var c__4638__auto___33949 = cljs.core.chunk_first(seq__33102_33948__$1);
var G__33950 = cljs.core.chunk_rest(seq__33102_33948__$1);
var G__33951 = c__4638__auto___33949;
var G__33952 = cljs.core.count(c__4638__auto___33949);
var G__33953 = (0);
seq__33102_33908 = G__33950;
chunk__33103_33909 = G__33951;
count__33104_33910 = G__33952;
i__33105_33911 = G__33953;
continue;
} else {
var child_struct_33954 = cljs.core.first(seq__33102_33948__$1);
var children_33955 = shadow.dom.dom_node(child_struct_33954);
if(cljs.core.seq_QMARK_(children_33955)){
var seq__33204_33956 = cljs.core.seq(cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom.dom_node,children_33955));
var chunk__33206_33957 = null;
var count__33207_33958 = (0);
var i__33208_33959 = (0);
while(true){
if((i__33208_33959 < count__33207_33958)){
var child_33960 = chunk__33206_33957.cljs$core$IIndexed$_nth$arity$2(null,i__33208_33959);
if(cljs.core.truth_(child_33960)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_33960);


var G__33961 = seq__33204_33956;
var G__33962 = chunk__33206_33957;
var G__33963 = count__33207_33958;
var G__33964 = (i__33208_33959 + (1));
seq__33204_33956 = G__33961;
chunk__33206_33957 = G__33962;
count__33207_33958 = G__33963;
i__33208_33959 = G__33964;
continue;
} else {
var G__33965 = seq__33204_33956;
var G__33966 = chunk__33206_33957;
var G__33967 = count__33207_33958;
var G__33968 = (i__33208_33959 + (1));
seq__33204_33956 = G__33965;
chunk__33206_33957 = G__33966;
count__33207_33958 = G__33967;
i__33208_33959 = G__33968;
continue;
}
} else {
var temp__5753__auto___33969__$1 = cljs.core.seq(seq__33204_33956);
if(temp__5753__auto___33969__$1){
var seq__33204_33970__$1 = temp__5753__auto___33969__$1;
if(cljs.core.chunked_seq_QMARK_(seq__33204_33970__$1)){
var c__4638__auto___33971 = cljs.core.chunk_first(seq__33204_33970__$1);
var G__33972 = cljs.core.chunk_rest(seq__33204_33970__$1);
var G__33973 = c__4638__auto___33971;
var G__33974 = cljs.core.count(c__4638__auto___33971);
var G__33975 = (0);
seq__33204_33956 = G__33972;
chunk__33206_33957 = G__33973;
count__33207_33958 = G__33974;
i__33208_33959 = G__33975;
continue;
} else {
var child_33977 = cljs.core.first(seq__33204_33970__$1);
if(cljs.core.truth_(child_33977)){
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,child_33977);


var G__33978 = cljs.core.next(seq__33204_33970__$1);
var G__33979 = null;
var G__33980 = (0);
var G__33981 = (0);
seq__33204_33956 = G__33978;
chunk__33206_33957 = G__33979;
count__33207_33958 = G__33980;
i__33208_33959 = G__33981;
continue;
} else {
var G__33982 = cljs.core.next(seq__33204_33970__$1);
var G__33983 = null;
var G__33984 = (0);
var G__33985 = (0);
seq__33204_33956 = G__33982;
chunk__33206_33957 = G__33983;
count__33207_33958 = G__33984;
i__33208_33959 = G__33985;
continue;
}
}
} else {
}
}
break;
}
} else {
shadow.dom.append.cljs$core$IFn$_invoke$arity$2(node,children_33955);
}


var G__33986 = cljs.core.next(seq__33102_33948__$1);
var G__33987 = null;
var G__33988 = (0);
var G__33989 = (0);
seq__33102_33908 = G__33986;
chunk__33103_33909 = G__33987;
count__33104_33910 = G__33988;
i__33105_33911 = G__33989;
continue;
}
} else {
}
}
break;
}

return node;
});
(cljs.core.Keyword.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.Keyword.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return shadow.dom.make_dom_node(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [this$__$1], null));
}));

(cljs.core.PersistentVector.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.PersistentVector.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return shadow.dom.make_dom_node(this$__$1);
}));

(cljs.core.LazySeq.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.LazySeq.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom._to_dom,this$__$1);
}));
if(cljs.core.truth_(((typeof HTMLElement) != 'undefined'))){
(HTMLElement.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL);

(HTMLElement.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return this$__$1;
}));
} else {
}
if(cljs.core.truth_(((typeof DocumentFragment) != 'undefined'))){
(DocumentFragment.prototype.shadow$dom$IElement$ = cljs.core.PROTOCOL_SENTINEL);

(DocumentFragment.prototype.shadow$dom$IElement$_to_dom$arity$1 = (function (this$){
var this$__$1 = this;
return this$__$1;
}));
} else {
}
/**
 * clear node children
 */
shadow.dom.reset = (function shadow$dom$reset(node){
return goog.dom.removeChildren(shadow.dom.dom_node(node));
});
shadow.dom.remove = (function shadow$dom$remove(node){
if((((!((node == null))))?(((((node.cljs$lang$protocol_mask$partition0$ & (8388608))) || ((cljs.core.PROTOCOL_SENTINEL === node.cljs$core$ISeqable$))))?true:false):false)){
var seq__33259 = cljs.core.seq(node);
var chunk__33260 = null;
var count__33261 = (0);
var i__33262 = (0);
while(true){
if((i__33262 < count__33261)){
var n = chunk__33260.cljs$core$IIndexed$_nth$arity$2(null,i__33262);
(shadow.dom.remove.cljs$core$IFn$_invoke$arity$1 ? shadow.dom.remove.cljs$core$IFn$_invoke$arity$1(n) : shadow.dom.remove.call(null,n));


var G__33991 = seq__33259;
var G__33992 = chunk__33260;
var G__33993 = count__33261;
var G__33994 = (i__33262 + (1));
seq__33259 = G__33991;
chunk__33260 = G__33992;
count__33261 = G__33993;
i__33262 = G__33994;
continue;
} else {
var temp__5753__auto__ = cljs.core.seq(seq__33259);
if(temp__5753__auto__){
var seq__33259__$1 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__33259__$1)){
var c__4638__auto__ = cljs.core.chunk_first(seq__33259__$1);
var G__33995 = cljs.core.chunk_rest(seq__33259__$1);
var G__33996 = c__4638__auto__;
var G__33997 = cljs.core.count(c__4638__auto__);
var G__33998 = (0);
seq__33259 = G__33995;
chunk__33260 = G__33996;
count__33261 = G__33997;
i__33262 = G__33998;
continue;
} else {
var n = cljs.core.first(seq__33259__$1);
(shadow.dom.remove.cljs$core$IFn$_invoke$arity$1 ? shadow.dom.remove.cljs$core$IFn$_invoke$arity$1(n) : shadow.dom.remove.call(null,n));


var G__33999 = cljs.core.next(seq__33259__$1);
var G__34000 = null;
var G__34001 = (0);
var G__34002 = (0);
seq__33259 = G__33999;
chunk__33260 = G__34000;
count__33261 = G__34001;
i__33262 = G__34002;
continue;
}
} else {
return null;
}
}
break;
}
} else {
return goog.dom.removeNode(node);
}
});
shadow.dom.replace_node = (function shadow$dom$replace_node(old,new$){
return goog.dom.replaceNode(shadow.dom.dom_node(new$),shadow.dom.dom_node(old));
});
shadow.dom.text = (function shadow$dom$text(var_args){
var G__33288 = arguments.length;
switch (G__33288) {
case 2:
return shadow.dom.text.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return shadow.dom.text.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.text.cljs$core$IFn$_invoke$arity$2 = (function (el,new_text){
return (shadow.dom.dom_node(el).innerText = new_text);
}));

(shadow.dom.text.cljs$core$IFn$_invoke$arity$1 = (function (el){
return shadow.dom.dom_node(el).innerText;
}));

(shadow.dom.text.cljs$lang$maxFixedArity = 2);

shadow.dom.check = (function shadow$dom$check(var_args){
var G__33298 = arguments.length;
switch (G__33298) {
case 1:
return shadow.dom.check.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.check.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.check.cljs$core$IFn$_invoke$arity$1 = (function (el){
return shadow.dom.check.cljs$core$IFn$_invoke$arity$2(el,true);
}));

(shadow.dom.check.cljs$core$IFn$_invoke$arity$2 = (function (el,checked){
return (shadow.dom.dom_node(el).checked = checked);
}));

(shadow.dom.check.cljs$lang$maxFixedArity = 2);

shadow.dom.checked_QMARK_ = (function shadow$dom$checked_QMARK_(el){
return shadow.dom.dom_node(el).checked;
});
shadow.dom.form_elements = (function shadow$dom$form_elements(el){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(el).elements));
});
shadow.dom.children = (function shadow$dom$children(el){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(el).children));
});
shadow.dom.child_nodes = (function shadow$dom$child_nodes(el){
return (new shadow.dom.NativeColl(shadow.dom.dom_node(el).childNodes));
});
shadow.dom.attr = (function shadow$dom$attr(var_args){
var G__33320 = arguments.length;
switch (G__33320) {
case 2:
return shadow.dom.attr.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.attr.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.attr.cljs$core$IFn$_invoke$arity$2 = (function (el,key){
return shadow.dom.dom_node(el).getAttribute(cljs.core.name(key));
}));

(shadow.dom.attr.cljs$core$IFn$_invoke$arity$3 = (function (el,key,default$){
var or__4212__auto__ = shadow.dom.dom_node(el).getAttribute(cljs.core.name(key));
if(cljs.core.truth_(or__4212__auto__)){
return or__4212__auto__;
} else {
return default$;
}
}));

(shadow.dom.attr.cljs$lang$maxFixedArity = 3);

shadow.dom.del_attr = (function shadow$dom$del_attr(el,key){
return shadow.dom.dom_node(el).removeAttribute(cljs.core.name(key));
});
shadow.dom.data = (function shadow$dom$data(el,key){
return shadow.dom.dom_node(el).getAttribute(["data-",cljs.core.name(key)].join(''));
});
shadow.dom.set_data = (function shadow$dom$set_data(el,key,value){
return shadow.dom.dom_node(el).setAttribute(["data-",cljs.core.name(key)].join(''),cljs.core.str.cljs$core$IFn$_invoke$arity$1(value));
});
shadow.dom.set_html = (function shadow$dom$set_html(node,text){
return (shadow.dom.dom_node(node).innerHTML = text);
});
shadow.dom.get_html = (function shadow$dom$get_html(node){
return shadow.dom.dom_node(node).innerHTML;
});
shadow.dom.fragment = (function shadow$dom$fragment(var_args){
var args__4824__auto__ = [];
var len__4818__auto___34007 = arguments.length;
var i__4819__auto___34008 = (0);
while(true){
if((i__4819__auto___34008 < len__4818__auto___34007)){
args__4824__auto__.push((arguments[i__4819__auto___34008]));

var G__34009 = (i__4819__auto___34008 + (1));
i__4819__auto___34008 = G__34009;
continue;
} else {
}
break;
}

var argseq__4825__auto__ = ((((0) < args__4824__auto__.length))?(new cljs.core.IndexedSeq(args__4824__auto__.slice((0)),(0),null)):null);
return shadow.dom.fragment.cljs$core$IFn$_invoke$arity$variadic(argseq__4825__auto__);
});

(shadow.dom.fragment.cljs$core$IFn$_invoke$arity$variadic = (function (nodes){
var fragment = document.createDocumentFragment();
var seq__33343_34010 = cljs.core.seq(nodes);
var chunk__33344_34011 = null;
var count__33345_34012 = (0);
var i__33346_34013 = (0);
while(true){
if((i__33346_34013 < count__33345_34012)){
var node_34014 = chunk__33344_34011.cljs$core$IIndexed$_nth$arity$2(null,i__33346_34013);
fragment.appendChild(shadow.dom._to_dom(node_34014));


var G__34015 = seq__33343_34010;
var G__34016 = chunk__33344_34011;
var G__34017 = count__33345_34012;
var G__34018 = (i__33346_34013 + (1));
seq__33343_34010 = G__34015;
chunk__33344_34011 = G__34016;
count__33345_34012 = G__34017;
i__33346_34013 = G__34018;
continue;
} else {
var temp__5753__auto___34019 = cljs.core.seq(seq__33343_34010);
if(temp__5753__auto___34019){
var seq__33343_34021__$1 = temp__5753__auto___34019;
if(cljs.core.chunked_seq_QMARK_(seq__33343_34021__$1)){
var c__4638__auto___34022 = cljs.core.chunk_first(seq__33343_34021__$1);
var G__34023 = cljs.core.chunk_rest(seq__33343_34021__$1);
var G__34024 = c__4638__auto___34022;
var G__34025 = cljs.core.count(c__4638__auto___34022);
var G__34026 = (0);
seq__33343_34010 = G__34023;
chunk__33344_34011 = G__34024;
count__33345_34012 = G__34025;
i__33346_34013 = G__34026;
continue;
} else {
var node_34027 = cljs.core.first(seq__33343_34021__$1);
fragment.appendChild(shadow.dom._to_dom(node_34027));


var G__34028 = cljs.core.next(seq__33343_34021__$1);
var G__34029 = null;
var G__34030 = (0);
var G__34031 = (0);
seq__33343_34010 = G__34028;
chunk__33344_34011 = G__34029;
count__33345_34012 = G__34030;
i__33346_34013 = G__34031;
continue;
}
} else {
}
}
break;
}

return (new shadow.dom.NativeColl(fragment));
}));

(shadow.dom.fragment.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(shadow.dom.fragment.cljs$lang$applyTo = (function (seq33336){
var self__4806__auto__ = this;
return self__4806__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq(seq33336));
}));

/**
 * given a html string, eval all <script> tags and return the html without the scripts
 * don't do this for everything, only content you trust.
 */
shadow.dom.eval_scripts = (function shadow$dom$eval_scripts(s){
var scripts = cljs.core.re_seq(/<script[^>]*?>(.+?)<\/script>/,s);
var seq__33359_34032 = cljs.core.seq(scripts);
var chunk__33360_34033 = null;
var count__33361_34034 = (0);
var i__33362_34035 = (0);
while(true){
if((i__33362_34035 < count__33361_34034)){
var vec__33369_34036 = chunk__33360_34033.cljs$core$IIndexed$_nth$arity$2(null,i__33362_34035);
var script_tag_34037 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33369_34036,(0),null);
var script_body_34038 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33369_34036,(1),null);
eval(script_body_34038);


var G__34039 = seq__33359_34032;
var G__34040 = chunk__33360_34033;
var G__34041 = count__33361_34034;
var G__34042 = (i__33362_34035 + (1));
seq__33359_34032 = G__34039;
chunk__33360_34033 = G__34040;
count__33361_34034 = G__34041;
i__33362_34035 = G__34042;
continue;
} else {
var temp__5753__auto___34044 = cljs.core.seq(seq__33359_34032);
if(temp__5753__auto___34044){
var seq__33359_34045__$1 = temp__5753__auto___34044;
if(cljs.core.chunked_seq_QMARK_(seq__33359_34045__$1)){
var c__4638__auto___34046 = cljs.core.chunk_first(seq__33359_34045__$1);
var G__34047 = cljs.core.chunk_rest(seq__33359_34045__$1);
var G__34048 = c__4638__auto___34046;
var G__34049 = cljs.core.count(c__4638__auto___34046);
var G__34050 = (0);
seq__33359_34032 = G__34047;
chunk__33360_34033 = G__34048;
count__33361_34034 = G__34049;
i__33362_34035 = G__34050;
continue;
} else {
var vec__33372_34052 = cljs.core.first(seq__33359_34045__$1);
var script_tag_34053 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33372_34052,(0),null);
var script_body_34054 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33372_34052,(1),null);
eval(script_body_34054);


var G__34055 = cljs.core.next(seq__33359_34045__$1);
var G__34056 = null;
var G__34057 = (0);
var G__34058 = (0);
seq__33359_34032 = G__34055;
chunk__33360_34033 = G__34056;
count__33361_34034 = G__34057;
i__33362_34035 = G__34058;
continue;
}
} else {
}
}
break;
}

return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (s__$1,p__33375){
var vec__33376 = p__33375;
var script_tag = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33376,(0),null);
var script_body = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33376,(1),null);
return clojure.string.replace(s__$1,script_tag,"");
}),s,scripts);
});
shadow.dom.str__GT_fragment = (function shadow$dom$str__GT_fragment(s){
var el = document.createElement("div");
(el.innerHTML = s);

return (new shadow.dom.NativeColl(goog.dom.childrenToNode_(document,el)));
});
shadow.dom.node_name = (function shadow$dom$node_name(el){
return shadow.dom.dom_node(el).nodeName;
});
shadow.dom.ancestor_by_class = (function shadow$dom$ancestor_by_class(el,cls){
return goog.dom.getAncestorByClass(shadow.dom.dom_node(el),cls);
});
shadow.dom.ancestor_by_tag = (function shadow$dom$ancestor_by_tag(var_args){
var G__33391 = arguments.length;
switch (G__33391) {
case 2:
return shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$2 = (function (el,tag){
return goog.dom.getAncestorByTagNameAndClass(shadow.dom.dom_node(el),cljs.core.name(tag));
}));

(shadow.dom.ancestor_by_tag.cljs$core$IFn$_invoke$arity$3 = (function (el,tag,cls){
return goog.dom.getAncestorByTagNameAndClass(shadow.dom.dom_node(el),cljs.core.name(tag),cljs.core.name(cls));
}));

(shadow.dom.ancestor_by_tag.cljs$lang$maxFixedArity = 3);

shadow.dom.get_value = (function shadow$dom$get_value(dom){
return goog.dom.forms.getValue(shadow.dom.dom_node(dom));
});
shadow.dom.set_value = (function shadow$dom$set_value(dom,value){
return goog.dom.forms.setValue(shadow.dom.dom_node(dom),value);
});
shadow.dom.px = (function shadow$dom$px(value){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1((value | (0))),"px"].join('');
});
shadow.dom.pct = (function shadow$dom$pct(value){
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(value),"%"].join('');
});
shadow.dom.remove_style_STAR_ = (function shadow$dom$remove_style_STAR_(el,style){
return el.style.removeProperty(cljs.core.name(style));
});
shadow.dom.remove_style = (function shadow$dom$remove_style(el,style){
var el__$1 = shadow.dom.dom_node(el);
return shadow.dom.remove_style_STAR_(el__$1,style);
});
shadow.dom.remove_styles = (function shadow$dom$remove_styles(el,style_keys){
var el__$1 = shadow.dom.dom_node(el);
var seq__33424 = cljs.core.seq(style_keys);
var chunk__33425 = null;
var count__33426 = (0);
var i__33427 = (0);
while(true){
if((i__33427 < count__33426)){
var it = chunk__33425.cljs$core$IIndexed$_nth$arity$2(null,i__33427);
shadow.dom.remove_style_STAR_(el__$1,it);


var G__34062 = seq__33424;
var G__34063 = chunk__33425;
var G__34064 = count__33426;
var G__34065 = (i__33427 + (1));
seq__33424 = G__34062;
chunk__33425 = G__34063;
count__33426 = G__34064;
i__33427 = G__34065;
continue;
} else {
var temp__5753__auto__ = cljs.core.seq(seq__33424);
if(temp__5753__auto__){
var seq__33424__$1 = temp__5753__auto__;
if(cljs.core.chunked_seq_QMARK_(seq__33424__$1)){
var c__4638__auto__ = cljs.core.chunk_first(seq__33424__$1);
var G__34066 = cljs.core.chunk_rest(seq__33424__$1);
var G__34067 = c__4638__auto__;
var G__34068 = cljs.core.count(c__4638__auto__);
var G__34069 = (0);
seq__33424 = G__34066;
chunk__33425 = G__34067;
count__33426 = G__34068;
i__33427 = G__34069;
continue;
} else {
var it = cljs.core.first(seq__33424__$1);
shadow.dom.remove_style_STAR_(el__$1,it);


var G__34070 = cljs.core.next(seq__33424__$1);
var G__34071 = null;
var G__34072 = (0);
var G__34073 = (0);
seq__33424 = G__34070;
chunk__33425 = G__34071;
count__33426 = G__34072;
i__33427 = G__34073;
continue;
}
} else {
return null;
}
}
break;
}
});

/**
* @constructor
 * @implements {cljs.core.IRecord}
 * @implements {cljs.core.IKVReduce}
 * @implements {cljs.core.IEquiv}
 * @implements {cljs.core.IHash}
 * @implements {cljs.core.ICollection}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.ICloneable}
 * @implements {cljs.core.IPrintWithWriter}
 * @implements {cljs.core.IIterable}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.IAssociative}
 * @implements {cljs.core.IMap}
 * @implements {cljs.core.ILookup}
*/
shadow.dom.Coordinate = (function (x,y,__meta,__extmap,__hash){
this.x = x;
this.y = y;
this.__meta = __meta;
this.__extmap = __extmap;
this.__hash = __hash;
this.cljs$lang$protocol_mask$partition0$ = 2230716170;
this.cljs$lang$protocol_mask$partition1$ = 139264;
});
(shadow.dom.Coordinate.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (this__4461__auto__,k__4462__auto__){
var self__ = this;
var this__4461__auto____$1 = this;
return this__4461__auto____$1.cljs$core$ILookup$_lookup$arity$3(null,k__4462__auto__,null);
}));

(shadow.dom.Coordinate.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (this__4463__auto__,k33441,else__4464__auto__){
var self__ = this;
var this__4463__auto____$1 = this;
var G__33453 = k33441;
var G__33453__$1 = (((G__33453 instanceof cljs.core.Keyword))?G__33453.fqn:null);
switch (G__33453__$1) {
case "x":
return self__.x;

break;
case "y":
return self__.y;

break;
default:
return cljs.core.get.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k33441,else__4464__auto__);

}
}));

(shadow.dom.Coordinate.prototype.cljs$core$IKVReduce$_kv_reduce$arity$3 = (function (this__4481__auto__,f__4482__auto__,init__4483__auto__){
var self__ = this;
var this__4481__auto____$1 = this;
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (ret__4484__auto__,p__33458){
var vec__33460 = p__33458;
var k__4485__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33460,(0),null);
var v__4486__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33460,(1),null);
return (f__4482__auto__.cljs$core$IFn$_invoke$arity$3 ? f__4482__auto__.cljs$core$IFn$_invoke$arity$3(ret__4484__auto__,k__4485__auto__,v__4486__auto__) : f__4482__auto__.call(null,ret__4484__auto__,k__4485__auto__,v__4486__auto__));
}),init__4483__auto__,this__4481__auto____$1);
}));

(shadow.dom.Coordinate.prototype.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = (function (this__4476__auto__,writer__4477__auto__,opts__4478__auto__){
var self__ = this;
var this__4476__auto____$1 = this;
var pr_pair__4479__auto__ = (function (keyval__4480__auto__){
return cljs.core.pr_sequential_writer(writer__4477__auto__,cljs.core.pr_writer,""," ","",opts__4478__auto__,keyval__4480__auto__);
});
return cljs.core.pr_sequential_writer(writer__4477__auto__,pr_pair__4479__auto__,"#shadow.dom.Coordinate{",", ","}",opts__4478__auto__,cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"x","x",2099068185),self__.x],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"y","y",-1757859776),self__.y],null))], null),self__.__extmap));
}));

(shadow.dom.Coordinate.prototype.cljs$core$IIterable$_iterator$arity$1 = (function (G__33440){
var self__ = this;
var G__33440__$1 = this;
return (new cljs.core.RecordIter((0),G__33440__$1,2,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"x","x",2099068185),new cljs.core.Keyword(null,"y","y",-1757859776)], null),(cljs.core.truth_(self__.__extmap)?cljs.core._iterator(self__.__extmap):cljs.core.nil_iter())));
}));

(shadow.dom.Coordinate.prototype.cljs$core$IMeta$_meta$arity$1 = (function (this__4459__auto__){
var self__ = this;
var this__4459__auto____$1 = this;
return self__.__meta;
}));

(shadow.dom.Coordinate.prototype.cljs$core$ICloneable$_clone$arity$1 = (function (this__4456__auto__){
var self__ = this;
var this__4456__auto____$1 = this;
return (new shadow.dom.Coordinate(self__.x,self__.y,self__.__meta,self__.__extmap,self__.__hash));
}));

(shadow.dom.Coordinate.prototype.cljs$core$ICounted$_count$arity$1 = (function (this__4465__auto__){
var self__ = this;
var this__4465__auto____$1 = this;
return (2 + cljs.core.count(self__.__extmap));
}));

(shadow.dom.Coordinate.prototype.cljs$core$IHash$_hash$arity$1 = (function (this__4457__auto__){
var self__ = this;
var this__4457__auto____$1 = this;
var h__4319__auto__ = self__.__hash;
if((!((h__4319__auto__ == null)))){
return h__4319__auto__;
} else {
var h__4319__auto____$1 = (function (coll__4458__auto__){
return (145542109 ^ cljs.core.hash_unordered_coll(coll__4458__auto__));
})(this__4457__auto____$1);
(self__.__hash = h__4319__auto____$1);

return h__4319__auto____$1;
}
}));

(shadow.dom.Coordinate.prototype.cljs$core$IEquiv$_equiv$arity$2 = (function (this33442,other33443){
var self__ = this;
var this33442__$1 = this;
return (((!((other33443 == null)))) && ((((this33442__$1.constructor === other33443.constructor)) && (((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this33442__$1.x,other33443.x)) && (((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this33442__$1.y,other33443.y)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this33442__$1.__extmap,other33443.__extmap)))))))));
}));

(shadow.dom.Coordinate.prototype.cljs$core$IMap$_dissoc$arity$2 = (function (this__4471__auto__,k__4472__auto__){
var self__ = this;
var this__4471__auto____$1 = this;
if(cljs.core.contains_QMARK_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"y","y",-1757859776),null,new cljs.core.Keyword(null,"x","x",2099068185),null], null), null),k__4472__auto__)){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(cljs.core._with_meta(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,this__4471__auto____$1),self__.__meta),k__4472__auto__);
} else {
return (new shadow.dom.Coordinate(self__.x,self__.y,self__.__meta,cljs.core.not_empty(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(self__.__extmap,k__4472__auto__)),null));
}
}));

(shadow.dom.Coordinate.prototype.cljs$core$IAssociative$_contains_key_QMARK_$arity$2 = (function (this__4468__auto__,k33441){
var self__ = this;
var this__4468__auto____$1 = this;
var G__33490 = k33441;
var G__33490__$1 = (((G__33490 instanceof cljs.core.Keyword))?G__33490.fqn:null);
switch (G__33490__$1) {
case "x":
case "y":
return true;

break;
default:
return cljs.core.contains_QMARK_(self__.__extmap,k33441);

}
}));

(shadow.dom.Coordinate.prototype.cljs$core$IAssociative$_assoc$arity$3 = (function (this__4469__auto__,k__4470__auto__,G__33440){
var self__ = this;
var this__4469__auto____$1 = this;
var pred__33493 = cljs.core.keyword_identical_QMARK_;
var expr__33494 = k__4470__auto__;
if(cljs.core.truth_((pred__33493.cljs$core$IFn$_invoke$arity$2 ? pred__33493.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"x","x",2099068185),expr__33494) : pred__33493.call(null,new cljs.core.Keyword(null,"x","x",2099068185),expr__33494)))){
return (new shadow.dom.Coordinate(G__33440,self__.y,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_((pred__33493.cljs$core$IFn$_invoke$arity$2 ? pred__33493.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"y","y",-1757859776),expr__33494) : pred__33493.call(null,new cljs.core.Keyword(null,"y","y",-1757859776),expr__33494)))){
return (new shadow.dom.Coordinate(self__.x,G__33440,self__.__meta,self__.__extmap,null));
} else {
return (new shadow.dom.Coordinate(self__.x,self__.y,self__.__meta,cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k__4470__auto__,G__33440),null));
}
}
}));

(shadow.dom.Coordinate.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this__4474__auto__){
var self__ = this;
var this__4474__auto____$1 = this;
return cljs.core.seq(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.MapEntry(new cljs.core.Keyword(null,"x","x",2099068185),self__.x,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"y","y",-1757859776),self__.y,null))], null),self__.__extmap));
}));

(shadow.dom.Coordinate.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (this__4460__auto__,G__33440){
var self__ = this;
var this__4460__auto____$1 = this;
return (new shadow.dom.Coordinate(self__.x,self__.y,G__33440,self__.__extmap,self__.__hash));
}));

(shadow.dom.Coordinate.prototype.cljs$core$ICollection$_conj$arity$2 = (function (this__4466__auto__,entry__4467__auto__){
var self__ = this;
var this__4466__auto____$1 = this;
if(cljs.core.vector_QMARK_(entry__4467__auto__)){
return this__4466__auto____$1.cljs$core$IAssociative$_assoc$arity$3(null,cljs.core._nth(entry__4467__auto__,(0)),cljs.core._nth(entry__4467__auto__,(1)));
} else {
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(cljs.core._conj,this__4466__auto____$1,entry__4467__auto__);
}
}));

(shadow.dom.Coordinate.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"x","x",-555367584,null),new cljs.core.Symbol(null,"y","y",-117328249,null)], null);
}));

(shadow.dom.Coordinate.cljs$lang$type = true);

(shadow.dom.Coordinate.cljs$lang$ctorPrSeq = (function (this__4505__auto__){
return (new cljs.core.List(null,"shadow.dom/Coordinate",null,(1),null));
}));

(shadow.dom.Coordinate.cljs$lang$ctorPrWriter = (function (this__4505__auto__,writer__4506__auto__){
return cljs.core._write(writer__4506__auto__,"shadow.dom/Coordinate");
}));

/**
 * Positional factory function for shadow.dom/Coordinate.
 */
shadow.dom.__GT_Coordinate = (function shadow$dom$__GT_Coordinate(x,y){
return (new shadow.dom.Coordinate(x,y,null,null,null));
});

/**
 * Factory function for shadow.dom/Coordinate, taking a map of keywords to field values.
 */
shadow.dom.map__GT_Coordinate = (function shadow$dom$map__GT_Coordinate(G__33444){
var extmap__4501__auto__ = (function (){var G__33518 = cljs.core.dissoc.cljs$core$IFn$_invoke$arity$variadic(G__33444,new cljs.core.Keyword(null,"x","x",2099068185),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"y","y",-1757859776)], 0));
if(cljs.core.record_QMARK_(G__33444)){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,G__33518);
} else {
return G__33518;
}
})();
return (new shadow.dom.Coordinate(new cljs.core.Keyword(null,"x","x",2099068185).cljs$core$IFn$_invoke$arity$1(G__33444),new cljs.core.Keyword(null,"y","y",-1757859776).cljs$core$IFn$_invoke$arity$1(G__33444),null,cljs.core.not_empty(extmap__4501__auto__),null));
});

shadow.dom.get_position = (function shadow$dom$get_position(el){
var pos = goog.style.getPosition(shadow.dom.dom_node(el));
return shadow.dom.__GT_Coordinate(pos.x,pos.y);
});
shadow.dom.get_client_position = (function shadow$dom$get_client_position(el){
var pos = goog.style.getClientPosition(shadow.dom.dom_node(el));
return shadow.dom.__GT_Coordinate(pos.x,pos.y);
});
shadow.dom.get_page_offset = (function shadow$dom$get_page_offset(el){
var pos = goog.style.getPageOffset(shadow.dom.dom_node(el));
return shadow.dom.__GT_Coordinate(pos.x,pos.y);
});

/**
* @constructor
 * @implements {cljs.core.IRecord}
 * @implements {cljs.core.IKVReduce}
 * @implements {cljs.core.IEquiv}
 * @implements {cljs.core.IHash}
 * @implements {cljs.core.ICollection}
 * @implements {cljs.core.ICounted}
 * @implements {cljs.core.ISeqable}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.ICloneable}
 * @implements {cljs.core.IPrintWithWriter}
 * @implements {cljs.core.IIterable}
 * @implements {cljs.core.IWithMeta}
 * @implements {cljs.core.IAssociative}
 * @implements {cljs.core.IMap}
 * @implements {cljs.core.ILookup}
*/
shadow.dom.Size = (function (w,h,__meta,__extmap,__hash){
this.w = w;
this.h = h;
this.__meta = __meta;
this.__extmap = __extmap;
this.__hash = __hash;
this.cljs$lang$protocol_mask$partition0$ = 2230716170;
this.cljs$lang$protocol_mask$partition1$ = 139264;
});
(shadow.dom.Size.prototype.cljs$core$ILookup$_lookup$arity$2 = (function (this__4461__auto__,k__4462__auto__){
var self__ = this;
var this__4461__auto____$1 = this;
return this__4461__auto____$1.cljs$core$ILookup$_lookup$arity$3(null,k__4462__auto__,null);
}));

(shadow.dom.Size.prototype.cljs$core$ILookup$_lookup$arity$3 = (function (this__4463__auto__,k33545,else__4464__auto__){
var self__ = this;
var this__4463__auto____$1 = this;
var G__33553 = k33545;
var G__33553__$1 = (((G__33553 instanceof cljs.core.Keyword))?G__33553.fqn:null);
switch (G__33553__$1) {
case "w":
return self__.w;

break;
case "h":
return self__.h;

break;
default:
return cljs.core.get.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k33545,else__4464__auto__);

}
}));

(shadow.dom.Size.prototype.cljs$core$IKVReduce$_kv_reduce$arity$3 = (function (this__4481__auto__,f__4482__auto__,init__4483__auto__){
var self__ = this;
var this__4481__auto____$1 = this;
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3((function (ret__4484__auto__,p__33554){
var vec__33555 = p__33554;
var k__4485__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33555,(0),null);
var v__4486__auto__ = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33555,(1),null);
return (f__4482__auto__.cljs$core$IFn$_invoke$arity$3 ? f__4482__auto__.cljs$core$IFn$_invoke$arity$3(ret__4484__auto__,k__4485__auto__,v__4486__auto__) : f__4482__auto__.call(null,ret__4484__auto__,k__4485__auto__,v__4486__auto__));
}),init__4483__auto__,this__4481__auto____$1);
}));

(shadow.dom.Size.prototype.cljs$core$IPrintWithWriter$_pr_writer$arity$3 = (function (this__4476__auto__,writer__4477__auto__,opts__4478__auto__){
var self__ = this;
var this__4476__auto____$1 = this;
var pr_pair__4479__auto__ = (function (keyval__4480__auto__){
return cljs.core.pr_sequential_writer(writer__4477__auto__,cljs.core.pr_writer,""," ","",opts__4478__auto__,keyval__4480__auto__);
});
return cljs.core.pr_sequential_writer(writer__4477__auto__,pr_pair__4479__auto__,"#shadow.dom.Size{",", ","}",opts__4478__auto__,cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"w","w",354169001),self__.w],null)),(new cljs.core.PersistentVector(null,2,(5),cljs.core.PersistentVector.EMPTY_NODE,[new cljs.core.Keyword(null,"h","h",1109658740),self__.h],null))], null),self__.__extmap));
}));

(shadow.dom.Size.prototype.cljs$core$IIterable$_iterator$arity$1 = (function (G__33544){
var self__ = this;
var G__33544__$1 = this;
return (new cljs.core.RecordIter((0),G__33544__$1,2,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"w","w",354169001),new cljs.core.Keyword(null,"h","h",1109658740)], null),(cljs.core.truth_(self__.__extmap)?cljs.core._iterator(self__.__extmap):cljs.core.nil_iter())));
}));

(shadow.dom.Size.prototype.cljs$core$IMeta$_meta$arity$1 = (function (this__4459__auto__){
var self__ = this;
var this__4459__auto____$1 = this;
return self__.__meta;
}));

(shadow.dom.Size.prototype.cljs$core$ICloneable$_clone$arity$1 = (function (this__4456__auto__){
var self__ = this;
var this__4456__auto____$1 = this;
return (new shadow.dom.Size(self__.w,self__.h,self__.__meta,self__.__extmap,self__.__hash));
}));

(shadow.dom.Size.prototype.cljs$core$ICounted$_count$arity$1 = (function (this__4465__auto__){
var self__ = this;
var this__4465__auto____$1 = this;
return (2 + cljs.core.count(self__.__extmap));
}));

(shadow.dom.Size.prototype.cljs$core$IHash$_hash$arity$1 = (function (this__4457__auto__){
var self__ = this;
var this__4457__auto____$1 = this;
var h__4319__auto__ = self__.__hash;
if((!((h__4319__auto__ == null)))){
return h__4319__auto__;
} else {
var h__4319__auto____$1 = (function (coll__4458__auto__){
return (-1228019642 ^ cljs.core.hash_unordered_coll(coll__4458__auto__));
})(this__4457__auto____$1);
(self__.__hash = h__4319__auto____$1);

return h__4319__auto____$1;
}
}));

(shadow.dom.Size.prototype.cljs$core$IEquiv$_equiv$arity$2 = (function (this33546,other33547){
var self__ = this;
var this33546__$1 = this;
return (((!((other33547 == null)))) && ((((this33546__$1.constructor === other33547.constructor)) && (((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this33546__$1.w,other33547.w)) && (((cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this33546__$1.h,other33547.h)) && (cljs.core._EQ_.cljs$core$IFn$_invoke$arity$2(this33546__$1.__extmap,other33547.__extmap)))))))));
}));

(shadow.dom.Size.prototype.cljs$core$IMap$_dissoc$arity$2 = (function (this__4471__auto__,k__4472__auto__){
var self__ = this;
var this__4471__auto____$1 = this;
if(cljs.core.contains_QMARK_(new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"w","w",354169001),null,new cljs.core.Keyword(null,"h","h",1109658740),null], null), null),k__4472__auto__)){
return cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(cljs.core._with_meta(cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,this__4471__auto____$1),self__.__meta),k__4472__auto__);
} else {
return (new shadow.dom.Size(self__.w,self__.h,self__.__meta,cljs.core.not_empty(cljs.core.dissoc.cljs$core$IFn$_invoke$arity$2(self__.__extmap,k__4472__auto__)),null));
}
}));

(shadow.dom.Size.prototype.cljs$core$IAssociative$_contains_key_QMARK_$arity$2 = (function (this__4468__auto__,k33545){
var self__ = this;
var this__4468__auto____$1 = this;
var G__33570 = k33545;
var G__33570__$1 = (((G__33570 instanceof cljs.core.Keyword))?G__33570.fqn:null);
switch (G__33570__$1) {
case "w":
case "h":
return true;

break;
default:
return cljs.core.contains_QMARK_(self__.__extmap,k33545);

}
}));

(shadow.dom.Size.prototype.cljs$core$IAssociative$_assoc$arity$3 = (function (this__4469__auto__,k__4470__auto__,G__33544){
var self__ = this;
var this__4469__auto____$1 = this;
var pred__33571 = cljs.core.keyword_identical_QMARK_;
var expr__33572 = k__4470__auto__;
if(cljs.core.truth_((pred__33571.cljs$core$IFn$_invoke$arity$2 ? pred__33571.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"w","w",354169001),expr__33572) : pred__33571.call(null,new cljs.core.Keyword(null,"w","w",354169001),expr__33572)))){
return (new shadow.dom.Size(G__33544,self__.h,self__.__meta,self__.__extmap,null));
} else {
if(cljs.core.truth_((pred__33571.cljs$core$IFn$_invoke$arity$2 ? pred__33571.cljs$core$IFn$_invoke$arity$2(new cljs.core.Keyword(null,"h","h",1109658740),expr__33572) : pred__33571.call(null,new cljs.core.Keyword(null,"h","h",1109658740),expr__33572)))){
return (new shadow.dom.Size(self__.w,G__33544,self__.__meta,self__.__extmap,null));
} else {
return (new shadow.dom.Size(self__.w,self__.h,self__.__meta,cljs.core.assoc.cljs$core$IFn$_invoke$arity$3(self__.__extmap,k__4470__auto__,G__33544),null));
}
}
}));

(shadow.dom.Size.prototype.cljs$core$ISeqable$_seq$arity$1 = (function (this__4474__auto__){
var self__ = this;
var this__4474__auto____$1 = this;
return cljs.core.seq(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [(new cljs.core.MapEntry(new cljs.core.Keyword(null,"w","w",354169001),self__.w,null)),(new cljs.core.MapEntry(new cljs.core.Keyword(null,"h","h",1109658740),self__.h,null))], null),self__.__extmap));
}));

(shadow.dom.Size.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (this__4460__auto__,G__33544){
var self__ = this;
var this__4460__auto____$1 = this;
return (new shadow.dom.Size(self__.w,self__.h,G__33544,self__.__extmap,self__.__hash));
}));

(shadow.dom.Size.prototype.cljs$core$ICollection$_conj$arity$2 = (function (this__4466__auto__,entry__4467__auto__){
var self__ = this;
var this__4466__auto____$1 = this;
if(cljs.core.vector_QMARK_(entry__4467__auto__)){
return this__4466__auto____$1.cljs$core$IAssociative$_assoc$arity$3(null,cljs.core._nth(entry__4467__auto__,(0)),cljs.core._nth(entry__4467__auto__,(1)));
} else {
return cljs.core.reduce.cljs$core$IFn$_invoke$arity$3(cljs.core._conj,this__4466__auto____$1,entry__4467__auto__);
}
}));

(shadow.dom.Size.getBasis = (function (){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"w","w",1994700528,null),new cljs.core.Symbol(null,"h","h",-1544777029,null)], null);
}));

(shadow.dom.Size.cljs$lang$type = true);

(shadow.dom.Size.cljs$lang$ctorPrSeq = (function (this__4505__auto__){
return (new cljs.core.List(null,"shadow.dom/Size",null,(1),null));
}));

(shadow.dom.Size.cljs$lang$ctorPrWriter = (function (this__4505__auto__,writer__4506__auto__){
return cljs.core._write(writer__4506__auto__,"shadow.dom/Size");
}));

/**
 * Positional factory function for shadow.dom/Size.
 */
shadow.dom.__GT_Size = (function shadow$dom$__GT_Size(w,h){
return (new shadow.dom.Size(w,h,null,null,null));
});

/**
 * Factory function for shadow.dom/Size, taking a map of keywords to field values.
 */
shadow.dom.map__GT_Size = (function shadow$dom$map__GT_Size(G__33551){
var extmap__4501__auto__ = (function (){var G__33588 = cljs.core.dissoc.cljs$core$IFn$_invoke$arity$variadic(G__33551,new cljs.core.Keyword(null,"w","w",354169001),cljs.core.prim_seq.cljs$core$IFn$_invoke$arity$2([new cljs.core.Keyword(null,"h","h",1109658740)], 0));
if(cljs.core.record_QMARK_(G__33551)){
return cljs.core.into.cljs$core$IFn$_invoke$arity$2(cljs.core.PersistentArrayMap.EMPTY,G__33588);
} else {
return G__33588;
}
})();
return (new shadow.dom.Size(new cljs.core.Keyword(null,"w","w",354169001).cljs$core$IFn$_invoke$arity$1(G__33551),new cljs.core.Keyword(null,"h","h",1109658740).cljs$core$IFn$_invoke$arity$1(G__33551),null,cljs.core.not_empty(extmap__4501__auto__),null));
});

shadow.dom.size__GT_clj = (function shadow$dom$size__GT_clj(size){
return (new shadow.dom.Size(size.width,size.height,null,null,null));
});
shadow.dom.get_size = (function shadow$dom$get_size(el){
return shadow.dom.size__GT_clj(goog.style.getSize(shadow.dom.dom_node(el)));
});
shadow.dom.get_height = (function shadow$dom$get_height(el){
return shadow.dom.get_size(el).h;
});
shadow.dom.get_viewport_size = (function shadow$dom$get_viewport_size(){
return shadow.dom.size__GT_clj(goog.dom.getViewportSize());
});
shadow.dom.first_child = (function shadow$dom$first_child(el){
return (shadow.dom.dom_node(el).children[(0)]);
});
shadow.dom.select_option_values = (function shadow$dom$select_option_values(el){
var native$ = shadow.dom.dom_node(el);
var opts = (native$["options"]);
var a__4692__auto__ = opts;
var l__4693__auto__ = a__4692__auto__.length;
var i = (0);
var ret = cljs.core.PersistentVector.EMPTY;
while(true){
if((i < l__4693__auto__)){
var G__34117 = (i + (1));
var G__34118 = cljs.core.conj.cljs$core$IFn$_invoke$arity$2(ret,(opts[i]["value"]));
i = G__34117;
ret = G__34118;
continue;
} else {
return ret;
}
break;
}
});
shadow.dom.build_url = (function shadow$dom$build_url(path,query_params){
if(cljs.core.empty_QMARK_(query_params)){
return path;
} else {
return [cljs.core.str.cljs$core$IFn$_invoke$arity$1(path),"?",clojure.string.join.cljs$core$IFn$_invoke$arity$2("&",cljs.core.map.cljs$core$IFn$_invoke$arity$2((function (p__33620){
var vec__33621 = p__33620;
var k = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33621,(0),null);
var v = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33621,(1),null);
return [cljs.core.name(k),"=",cljs.core.str.cljs$core$IFn$_invoke$arity$1(encodeURIComponent(cljs.core.str.cljs$core$IFn$_invoke$arity$1(v)))].join('');
}),query_params))].join('');
}
});
shadow.dom.redirect = (function shadow$dom$redirect(var_args){
var G__33630 = arguments.length;
switch (G__33630) {
case 1:
return shadow.dom.redirect.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return shadow.dom.redirect.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.redirect.cljs$core$IFn$_invoke$arity$1 = (function (path){
return shadow.dom.redirect.cljs$core$IFn$_invoke$arity$2(path,cljs.core.PersistentArrayMap.EMPTY);
}));

(shadow.dom.redirect.cljs$core$IFn$_invoke$arity$2 = (function (path,query_params){
return (document["location"]["href"] = shadow.dom.build_url(path,query_params));
}));

(shadow.dom.redirect.cljs$lang$maxFixedArity = 2);

shadow.dom.reload_BANG_ = (function shadow$dom$reload_BANG_(){
return (document.location.href = document.location.href);
});
shadow.dom.tag_name = (function shadow$dom$tag_name(el){
var dom = shadow.dom.dom_node(el);
return dom.tagName;
});
shadow.dom.insert_after = (function shadow$dom$insert_after(ref,new$){
var new_node = shadow.dom.dom_node(new$);
goog.dom.insertSiblingAfter(new_node,shadow.dom.dom_node(ref));

return new_node;
});
shadow.dom.insert_before = (function shadow$dom$insert_before(ref,new$){
var new_node = shadow.dom.dom_node(new$);
goog.dom.insertSiblingBefore(new_node,shadow.dom.dom_node(ref));

return new_node;
});
shadow.dom.insert_first = (function shadow$dom$insert_first(ref,new$){
var temp__5751__auto__ = shadow.dom.dom_node(ref).firstChild;
if(cljs.core.truth_(temp__5751__auto__)){
var child = temp__5751__auto__;
return shadow.dom.insert_before(child,new$);
} else {
return shadow.dom.append.cljs$core$IFn$_invoke$arity$2(ref,new$);
}
});
shadow.dom.index_of = (function shadow$dom$index_of(el){
var el__$1 = shadow.dom.dom_node(el);
var i = (0);
while(true){
var ps = el__$1.previousSibling;
if((ps == null)){
return i;
} else {
var G__34144 = ps;
var G__34145 = (i + (1));
el__$1 = G__34144;
i = G__34145;
continue;
}
break;
}
});
shadow.dom.get_parent = (function shadow$dom$get_parent(el){
return goog.dom.getParentElement(shadow.dom.dom_node(el));
});
shadow.dom.parents = (function shadow$dom$parents(el){
var parent = shadow.dom.get_parent(el);
if(cljs.core.truth_(parent)){
return cljs.core.cons(parent,(new cljs.core.LazySeq(null,(function (){
return (shadow.dom.parents.cljs$core$IFn$_invoke$arity$1 ? shadow.dom.parents.cljs$core$IFn$_invoke$arity$1(parent) : shadow.dom.parents.call(null,parent));
}),null,null)));
} else {
return null;
}
});
shadow.dom.matches = (function shadow$dom$matches(el,sel){
return shadow.dom.dom_node(el).matches(sel);
});
shadow.dom.get_next_sibling = (function shadow$dom$get_next_sibling(el){
return goog.dom.getNextElementSibling(shadow.dom.dom_node(el));
});
shadow.dom.get_previous_sibling = (function shadow$dom$get_previous_sibling(el){
return goog.dom.getPreviousElementSibling(shadow.dom.dom_node(el));
});
shadow.dom.xmlns = cljs.core.atom.cljs$core$IFn$_invoke$arity$1(new cljs.core.PersistentArrayMap(null, 2, ["svg","http://www.w3.org/2000/svg","xlink","http://www.w3.org/1999/xlink"], null));
shadow.dom.create_svg_node = (function shadow$dom$create_svg_node(tag_def,props){
var vec__33674 = shadow.dom.parse_tag(tag_def);
var tag_name = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33674,(0),null);
var tag_id = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33674,(1),null);
var tag_classes = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33674,(2),null);
var el = document.createElementNS("http://www.w3.org/2000/svg",tag_name);
if(cljs.core.truth_(tag_id)){
el.setAttribute("id",tag_id);
} else {
}

if(cljs.core.truth_(tag_classes)){
el.setAttribute("class",shadow.dom.merge_class_string(new cljs.core.Keyword(null,"class","class",-2030961996).cljs$core$IFn$_invoke$arity$1(props),tag_classes));
} else {
}

var seq__33681_34148 = cljs.core.seq(props);
var chunk__33682_34149 = null;
var count__33683_34150 = (0);
var i__33684_34151 = (0);
while(true){
if((i__33684_34151 < count__33683_34150)){
var vec__33706_34152 = chunk__33682_34149.cljs$core$IIndexed$_nth$arity$2(null,i__33684_34151);
var k_34153 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33706_34152,(0),null);
var v_34154 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33706_34152,(1),null);
el.setAttributeNS((function (){var temp__5753__auto__ = cljs.core.namespace(k_34153);
if(cljs.core.truth_(temp__5753__auto__)){
var ns = temp__5753__auto__;
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(shadow.dom.xmlns),ns);
} else {
return null;
}
})(),cljs.core.name(k_34153),v_34154);


var G__34155 = seq__33681_34148;
var G__34156 = chunk__33682_34149;
var G__34157 = count__33683_34150;
var G__34158 = (i__33684_34151 + (1));
seq__33681_34148 = G__34155;
chunk__33682_34149 = G__34156;
count__33683_34150 = G__34157;
i__33684_34151 = G__34158;
continue;
} else {
var temp__5753__auto___34159 = cljs.core.seq(seq__33681_34148);
if(temp__5753__auto___34159){
var seq__33681_34160__$1 = temp__5753__auto___34159;
if(cljs.core.chunked_seq_QMARK_(seq__33681_34160__$1)){
var c__4638__auto___34161 = cljs.core.chunk_first(seq__33681_34160__$1);
var G__34162 = cljs.core.chunk_rest(seq__33681_34160__$1);
var G__34163 = c__4638__auto___34161;
var G__34164 = cljs.core.count(c__4638__auto___34161);
var G__34165 = (0);
seq__33681_34148 = G__34162;
chunk__33682_34149 = G__34163;
count__33683_34150 = G__34164;
i__33684_34151 = G__34165;
continue;
} else {
var vec__33729_34166 = cljs.core.first(seq__33681_34160__$1);
var k_34167 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33729_34166,(0),null);
var v_34168 = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33729_34166,(1),null);
el.setAttributeNS((function (){var temp__5753__auto____$1 = cljs.core.namespace(k_34167);
if(cljs.core.truth_(temp__5753__auto____$1)){
var ns = temp__5753__auto____$1;
return cljs.core.get.cljs$core$IFn$_invoke$arity$2(cljs.core.deref(shadow.dom.xmlns),ns);
} else {
return null;
}
})(),cljs.core.name(k_34167),v_34168);


var G__34173 = cljs.core.next(seq__33681_34160__$1);
var G__34174 = null;
var G__34175 = (0);
var G__34176 = (0);
seq__33681_34148 = G__34173;
chunk__33682_34149 = G__34174;
count__33683_34150 = G__34175;
i__33684_34151 = G__34176;
continue;
}
} else {
}
}
break;
}

return el;
});
shadow.dom.svg_node = (function shadow$dom$svg_node(el){
if((el == null)){
return null;
} else {
if((((!((el == null))))?((((false) || ((cljs.core.PROTOCOL_SENTINEL === el.shadow$dom$SVGElement$))))?true:false):false)){
return el.shadow$dom$SVGElement$_to_svg$arity$1(null);
} else {
return el;

}
}
});
shadow.dom.make_svg_node = (function shadow$dom$make_svg_node(structure){
var vec__33753 = shadow.dom.destructure_node(shadow.dom.create_svg_node,structure);
var node = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33753,(0),null);
var node_children = cljs.core.nth.cljs$core$IFn$_invoke$arity$3(vec__33753,(1),null);
var seq__33756_34177 = cljs.core.seq(node_children);
var chunk__33758_34178 = null;
var count__33759_34179 = (0);
var i__33760_34180 = (0);
while(true){
if((i__33760_34180 < count__33759_34179)){
var child_struct_34181 = chunk__33758_34178.cljs$core$IIndexed$_nth$arity$2(null,i__33760_34180);
if((!((child_struct_34181 == null)))){
if(typeof child_struct_34181 === 'string'){
var text_34182 = (node["textContent"]);
(node["textContent"] = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(text_34182),child_struct_34181].join(''));
} else {
var children_34183 = shadow.dom.svg_node(child_struct_34181);
if(cljs.core.seq_QMARK_(children_34183)){
var seq__33792_34184 = cljs.core.seq(children_34183);
var chunk__33794_34185 = null;
var count__33795_34186 = (0);
var i__33796_34187 = (0);
while(true){
if((i__33796_34187 < count__33795_34186)){
var child_34188 = chunk__33794_34185.cljs$core$IIndexed$_nth$arity$2(null,i__33796_34187);
if(cljs.core.truth_(child_34188)){
node.appendChild(child_34188);


var G__34189 = seq__33792_34184;
var G__34190 = chunk__33794_34185;
var G__34191 = count__33795_34186;
var G__34192 = (i__33796_34187 + (1));
seq__33792_34184 = G__34189;
chunk__33794_34185 = G__34190;
count__33795_34186 = G__34191;
i__33796_34187 = G__34192;
continue;
} else {
var G__34193 = seq__33792_34184;
var G__34194 = chunk__33794_34185;
var G__34195 = count__33795_34186;
var G__34196 = (i__33796_34187 + (1));
seq__33792_34184 = G__34193;
chunk__33794_34185 = G__34194;
count__33795_34186 = G__34195;
i__33796_34187 = G__34196;
continue;
}
} else {
var temp__5753__auto___34197 = cljs.core.seq(seq__33792_34184);
if(temp__5753__auto___34197){
var seq__33792_34198__$1 = temp__5753__auto___34197;
if(cljs.core.chunked_seq_QMARK_(seq__33792_34198__$1)){
var c__4638__auto___34199 = cljs.core.chunk_first(seq__33792_34198__$1);
var G__34200 = cljs.core.chunk_rest(seq__33792_34198__$1);
var G__34201 = c__4638__auto___34199;
var G__34202 = cljs.core.count(c__4638__auto___34199);
var G__34203 = (0);
seq__33792_34184 = G__34200;
chunk__33794_34185 = G__34201;
count__33795_34186 = G__34202;
i__33796_34187 = G__34203;
continue;
} else {
var child_34207 = cljs.core.first(seq__33792_34198__$1);
if(cljs.core.truth_(child_34207)){
node.appendChild(child_34207);


var G__34208 = cljs.core.next(seq__33792_34198__$1);
var G__34209 = null;
var G__34210 = (0);
var G__34211 = (0);
seq__33792_34184 = G__34208;
chunk__33794_34185 = G__34209;
count__33795_34186 = G__34210;
i__33796_34187 = G__34211;
continue;
} else {
var G__34212 = cljs.core.next(seq__33792_34198__$1);
var G__34213 = null;
var G__34214 = (0);
var G__34215 = (0);
seq__33792_34184 = G__34212;
chunk__33794_34185 = G__34213;
count__33795_34186 = G__34214;
i__33796_34187 = G__34215;
continue;
}
}
} else {
}
}
break;
}
} else {
node.appendChild(children_34183);
}
}


var G__34216 = seq__33756_34177;
var G__34217 = chunk__33758_34178;
var G__34218 = count__33759_34179;
var G__34219 = (i__33760_34180 + (1));
seq__33756_34177 = G__34216;
chunk__33758_34178 = G__34217;
count__33759_34179 = G__34218;
i__33760_34180 = G__34219;
continue;
} else {
var G__34220 = seq__33756_34177;
var G__34221 = chunk__33758_34178;
var G__34222 = count__33759_34179;
var G__34223 = (i__33760_34180 + (1));
seq__33756_34177 = G__34220;
chunk__33758_34178 = G__34221;
count__33759_34179 = G__34222;
i__33760_34180 = G__34223;
continue;
}
} else {
var temp__5753__auto___34224 = cljs.core.seq(seq__33756_34177);
if(temp__5753__auto___34224){
var seq__33756_34225__$1 = temp__5753__auto___34224;
if(cljs.core.chunked_seq_QMARK_(seq__33756_34225__$1)){
var c__4638__auto___34226 = cljs.core.chunk_first(seq__33756_34225__$1);
var G__34227 = cljs.core.chunk_rest(seq__33756_34225__$1);
var G__34228 = c__4638__auto___34226;
var G__34229 = cljs.core.count(c__4638__auto___34226);
var G__34230 = (0);
seq__33756_34177 = G__34227;
chunk__33758_34178 = G__34228;
count__33759_34179 = G__34229;
i__33760_34180 = G__34230;
continue;
} else {
var child_struct_34231 = cljs.core.first(seq__33756_34225__$1);
if((!((child_struct_34231 == null)))){
if(typeof child_struct_34231 === 'string'){
var text_34232 = (node["textContent"]);
(node["textContent"] = [cljs.core.str.cljs$core$IFn$_invoke$arity$1(text_34232),child_struct_34231].join(''));
} else {
var children_34233 = shadow.dom.svg_node(child_struct_34231);
if(cljs.core.seq_QMARK_(children_34233)){
var seq__33802_34234 = cljs.core.seq(children_34233);
var chunk__33804_34235 = null;
var count__33805_34236 = (0);
var i__33806_34237 = (0);
while(true){
if((i__33806_34237 < count__33805_34236)){
var child_34238 = chunk__33804_34235.cljs$core$IIndexed$_nth$arity$2(null,i__33806_34237);
if(cljs.core.truth_(child_34238)){
node.appendChild(child_34238);


var G__34239 = seq__33802_34234;
var G__34240 = chunk__33804_34235;
var G__34241 = count__33805_34236;
var G__34242 = (i__33806_34237 + (1));
seq__33802_34234 = G__34239;
chunk__33804_34235 = G__34240;
count__33805_34236 = G__34241;
i__33806_34237 = G__34242;
continue;
} else {
var G__34243 = seq__33802_34234;
var G__34244 = chunk__33804_34235;
var G__34245 = count__33805_34236;
var G__34246 = (i__33806_34237 + (1));
seq__33802_34234 = G__34243;
chunk__33804_34235 = G__34244;
count__33805_34236 = G__34245;
i__33806_34237 = G__34246;
continue;
}
} else {
var temp__5753__auto___34247__$1 = cljs.core.seq(seq__33802_34234);
if(temp__5753__auto___34247__$1){
var seq__33802_34249__$1 = temp__5753__auto___34247__$1;
if(cljs.core.chunked_seq_QMARK_(seq__33802_34249__$1)){
var c__4638__auto___34252 = cljs.core.chunk_first(seq__33802_34249__$1);
var G__34253 = cljs.core.chunk_rest(seq__33802_34249__$1);
var G__34254 = c__4638__auto___34252;
var G__34255 = cljs.core.count(c__4638__auto___34252);
var G__34256 = (0);
seq__33802_34234 = G__34253;
chunk__33804_34235 = G__34254;
count__33805_34236 = G__34255;
i__33806_34237 = G__34256;
continue;
} else {
var child_34257 = cljs.core.first(seq__33802_34249__$1);
if(cljs.core.truth_(child_34257)){
node.appendChild(child_34257);


var G__34258 = cljs.core.next(seq__33802_34249__$1);
var G__34259 = null;
var G__34260 = (0);
var G__34261 = (0);
seq__33802_34234 = G__34258;
chunk__33804_34235 = G__34259;
count__33805_34236 = G__34260;
i__33806_34237 = G__34261;
continue;
} else {
var G__34262 = cljs.core.next(seq__33802_34249__$1);
var G__34263 = null;
var G__34264 = (0);
var G__34265 = (0);
seq__33802_34234 = G__34262;
chunk__33804_34235 = G__34263;
count__33805_34236 = G__34264;
i__33806_34237 = G__34265;
continue;
}
}
} else {
}
}
break;
}
} else {
node.appendChild(children_34233);
}
}


var G__34266 = cljs.core.next(seq__33756_34225__$1);
var G__34267 = null;
var G__34268 = (0);
var G__34269 = (0);
seq__33756_34177 = G__34266;
chunk__33758_34178 = G__34267;
count__33759_34179 = G__34268;
i__33760_34180 = G__34269;
continue;
} else {
var G__34270 = cljs.core.next(seq__33756_34225__$1);
var G__34271 = null;
var G__34272 = (0);
var G__34273 = (0);
seq__33756_34177 = G__34270;
chunk__33758_34178 = G__34271;
count__33759_34179 = G__34272;
i__33760_34180 = G__34273;
continue;
}
}
} else {
}
}
break;
}

return node;
});
goog.object.set(shadow.dom.SVGElement,"string",true);

goog.object.set(shadow.dom._to_svg,"string",(function (this$){
if((this$ instanceof cljs.core.Keyword)){
return shadow.dom.make_svg_node(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [this$], null));
} else {
throw cljs.core.ex_info.cljs$core$IFn$_invoke$arity$2("strings cannot be in svgs",new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"this","this",-611633625),this$], null));
}
}));

(cljs.core.PersistentVector.prototype.shadow$dom$SVGElement$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.PersistentVector.prototype.shadow$dom$SVGElement$_to_svg$arity$1 = (function (this$){
var this$__$1 = this;
return shadow.dom.make_svg_node(this$__$1);
}));

(cljs.core.LazySeq.prototype.shadow$dom$SVGElement$ = cljs.core.PROTOCOL_SENTINEL);

(cljs.core.LazySeq.prototype.shadow$dom$SVGElement$_to_svg$arity$1 = (function (this$){
var this$__$1 = this;
return cljs.core.map.cljs$core$IFn$_invoke$arity$2(shadow.dom._to_svg,this$__$1);
}));

goog.object.set(shadow.dom.SVGElement,"null",true);

goog.object.set(shadow.dom._to_svg,"null",(function (_){
return null;
}));
shadow.dom.svg = (function shadow$dom$svg(var_args){
var args__4824__auto__ = [];
var len__4818__auto___34274 = arguments.length;
var i__4819__auto___34275 = (0);
while(true){
if((i__4819__auto___34275 < len__4818__auto___34274)){
args__4824__auto__.push((arguments[i__4819__auto___34275]));

var G__34276 = (i__4819__auto___34275 + (1));
i__4819__auto___34275 = G__34276;
continue;
} else {
}
break;
}

var argseq__4825__auto__ = ((((1) < args__4824__auto__.length))?(new cljs.core.IndexedSeq(args__4824__auto__.slice((1)),(0),null)):null);
return shadow.dom.svg.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__4825__auto__);
});

(shadow.dom.svg.cljs$core$IFn$_invoke$arity$variadic = (function (attrs,children){
return shadow.dom._to_svg(cljs.core.vec(cljs.core.concat.cljs$core$IFn$_invoke$arity$2(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"svg","svg",856789142),attrs], null),children)));
}));

(shadow.dom.svg.cljs$lang$maxFixedArity = (1));

/** @this {Function} */
(shadow.dom.svg.cljs$lang$applyTo = (function (seq33813){
var G__33814 = cljs.core.first(seq33813);
var seq33813__$1 = cljs.core.next(seq33813);
var self__4805__auto__ = this;
return self__4805__auto__.cljs$core$IFn$_invoke$arity$variadic(G__33814,seq33813__$1);
}));

/**
 * returns a channel for events on el
 * transform-fn should be a (fn [e el] some-val) where some-val will be put on the chan
 * once-or-cleanup handles the removal of the event handler
 * - true: remove after one event
 * - false: never removed
 * - chan: remove on msg/close
 */
shadow.dom.event_chan = (function shadow$dom$event_chan(var_args){
var G__33816 = arguments.length;
switch (G__33816) {
case 2:
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",cljs.core.str.cljs$core$IFn$_invoke$arity$1(arguments.length)].join('')));

}
});

(shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$2 = (function (el,event){
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4(el,event,null,false);
}));

(shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$3 = (function (el,event,xf){
return shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4(el,event,xf,false);
}));

(shadow.dom.event_chan.cljs$core$IFn$_invoke$arity$4 = (function (el,event,xf,once_or_cleanup){
var buf = cljs.core.async.sliding_buffer((1));
var chan = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2(buf,xf);
var event_fn = (function shadow$dom$event_fn(e){
cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2(chan,e);

if(once_or_cleanup === true){
shadow.dom.remove_event_handler(el,event,shadow$dom$event_fn);

return cljs.core.async.close_BANG_(chan);
} else {
return null;
}
});
shadow.dom.dom_listen(shadow.dom.dom_node(el),cljs.core.name(event),event_fn);

if(cljs.core.truth_((function (){var and__4210__auto__ = once_or_cleanup;
if(cljs.core.truth_(and__4210__auto__)){
return (!(once_or_cleanup === true));
} else {
return and__4210__auto__;
}
})())){
var c__29167__auto___34281 = cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((1));
cljs.core.async.impl.dispatch.run((function (){
var f__29168__auto__ = (function (){var switch__28978__auto__ = (function (state_33828){
var state_val_33829 = (state_33828[(1)]);
if((state_val_33829 === (1))){
var state_33828__$1 = state_33828;
return cljs.core.async.impl.ioc_helpers.take_BANG_(state_33828__$1,(2),once_or_cleanup);
} else {
if((state_val_33829 === (2))){
var inst_33825 = (state_33828[(2)]);
var inst_33826 = shadow.dom.remove_event_handler(el,event,event_fn);
var state_33828__$1 = (function (){var statearr_33831 = state_33828;
(statearr_33831[(7)] = inst_33825);

return statearr_33831;
})();
return cljs.core.async.impl.ioc_helpers.return_chan(state_33828__$1,inst_33826);
} else {
return null;
}
}
});
return (function() {
var shadow$dom$state_machine__28979__auto__ = null;
var shadow$dom$state_machine__28979__auto____0 = (function (){
var statearr_33836 = [null,null,null,null,null,null,null,null];
(statearr_33836[(0)] = shadow$dom$state_machine__28979__auto__);

(statearr_33836[(1)] = (1));

return statearr_33836;
});
var shadow$dom$state_machine__28979__auto____1 = (function (state_33828){
while(true){
var ret_value__28980__auto__ = (function (){try{while(true){
var result__28981__auto__ = switch__28978__auto__(state_33828);
if(cljs.core.keyword_identical_QMARK_(result__28981__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__28981__auto__;
}
break;
}
}catch (e33837){var ex__28982__auto__ = e33837;
var statearr_33838_34282 = state_33828;
(statearr_33838_34282[(2)] = ex__28982__auto__);


if(cljs.core.seq((state_33828[(4)]))){
var statearr_33839_34283 = state_33828;
(statearr_33839_34283[(1)] = cljs.core.first((state_33828[(4)])));

} else {
throw ex__28982__auto__;
}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
}})();
if(cljs.core.keyword_identical_QMARK_(ret_value__28980__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__34284 = state_33828;
state_33828 = G__34284;
continue;
} else {
return ret_value__28980__auto__;
}
break;
}
});
shadow$dom$state_machine__28979__auto__ = function(state_33828){
switch(arguments.length){
case 0:
return shadow$dom$state_machine__28979__auto____0.call(this);
case 1:
return shadow$dom$state_machine__28979__auto____1.call(this,state_33828);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
shadow$dom$state_machine__28979__auto__.cljs$core$IFn$_invoke$arity$0 = shadow$dom$state_machine__28979__auto____0;
shadow$dom$state_machine__28979__auto__.cljs$core$IFn$_invoke$arity$1 = shadow$dom$state_machine__28979__auto____1;
return shadow$dom$state_machine__28979__auto__;
})()
})();
var state__29169__auto__ = (function (){var statearr_33840 = f__29168__auto__();
(statearr_33840[(6)] = c__29167__auto___34281);

return statearr_33840;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped(state__29169__auto__);
}));

} else {
}

return chan;
}));

(shadow.dom.event_chan.cljs$lang$maxFixedArity = 4);


//# sourceMappingURL=shadow.dom.js.map
